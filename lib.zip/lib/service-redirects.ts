/**
 * Human-friendly `/services/<slug>` aliases for the homepage "আরও দেখুন" links.
 * Each alias route immediately redirects to the canonical service page,
 * so no content is duplicated and links always work.
 */
export interface ServiceRedirectMap {
  slug: string;
  target: string;
}

export const SERVICE_REDIRECTS: ServiceRedirectMap[] = [
  { slug: 'toilet', target: '/tolet' },
  { slug: 'to-let', target: '/tolet' },
  { slug: 'electrician', target: '/electrician' },
  { slug: 'plumber', target: '/plumber' },
  { slug: 'maid', target: '/kajer-bua' },
  { slug: 'kajer-bua', target: '/kajer-bua' },
  { slug: 'tutor', target: '/home-tutor' },
  { slug: 'home-tutor', target: '/home-tutor' },
  { slug: 'blood-donor', target: '/blood-donor' },
  { slug: 'home-moving', target: '/home-moving' },
  { slug: 'gari-auto-cng', target: '/services?q=%E0%A6%97%E0%A6%BE%E0%A6%A1%E0%A6%BC%E0%A6%BF' },
  { slug: 'ac-fridge', target: '/ac-fridge' },
  { slug: 'buysell', target: '/buy-sell' },
  { slug: 'jobs', target: '/jobs' },
  { slug: 'news', target: '/news' },
  { slug: 'wifi', target: '/wifi' },
  { slug: 'coaching', target: '/coaching' },
  { slug: 'doctor', target: '/services?q=%E0%A6%A1%E0%A6%BE%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0' },
  { slug: 'police', target: '/services?q=%E0%A6%AA%E0%A7%81%E0%A6%B2%E0%A6%BF%E0%A6%B6' },
  { slug: 'ambulance', target: '/services?q=%E0%A6%85%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%AE%E0%A7%8D%E0%A6%AC%E0%A7%81%E0%A6%B2%E0%A7%87%E0%A6%A8%E0%A7%8D%E0%A6%B8' },
  { slug: 'fire-service', target: '/services?q=%E0%A6%AB%E0%A6%BE%E0%A6%AF%E0%A6%BC%E0%A6%BE%E0%A6%B0' },
  { slug: 'helpline', target: '/contact' },
];