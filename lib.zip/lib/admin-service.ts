/**
 * Centralized Admin data layer (Mymensingh Sheba).
 * Everything here is consumed ONLY behind the client-side `isAdmin` gate
 * (`app/admin/layout.tsx`). The real security boundary is Supabase RLS,
 * enforced by `public.is_admin()` and per-table policies in schema.sql.
 */
'use client';

import { isSupabaseConfigured, createClient } from './supabase/client';
import { createServerSideClient } from './supabase/server';
import { toCamelObject } from './supabase/transform';
import type {
  BloodDonorProfile,
  BloodDonorReport,
  HomeTutorProfile,
  ListingReport,
  NotificationItem,
  StaffProfile,
  StaffReport,
  TutorReport,
  TutorReview,
  ToletProfile,
  UserProfile,
  ServiceRequestStatus,
} from '@/lib/supabase/types';
import { DEFAULT_TOLET_FEE_RULES, type ToletFeeRules } from './tolet-fees';
import type {
  AdminUserRow,
  AdminReportRow,
  AdminReportStatus,
  AdminDashboardStats,
  PlatformSettings,
} from './admin-types';

export type { AdminUserRow, AdminReportRow, AdminReportStatus, AdminDashboardStats, PlatformSettings } from './admin-types';

// ---------------------------------------------------------------------------
// Mock fallbacks (preview mode — honest zeros, no fabricated statistics)
// ---------------------------------------------------------------------------

function mockDashboardStats(): AdminDashboardStats {
  return {
    users: 0,
    pendingVerifications: 0,
    publishedTutors: 0,
    publishedDonors: 0,
    activeStaff: 0,
    openRequests: 0,
    bloodPending: 0,
    openReports: 0,
    unreadAdminNotifs: 0,
  };
}

// ---------------------------------------------------------------------------
// Dashboard statistics (real counts from existing admin facades)
// ---------------------------------------------------------------------------

export async function fetchAdminDashboardStats(): Promise<AdminDashboardStats> {
  if (!isSupabaseConfigured) return mockDashboardStats();
  const client = createClient();
  if (!client) return mockDashboardStats();

  try {
    const [profilesRes, tutorsRes, donorsRes, staffRes, managedRes, bloodRes, reportsRes, notifsRes] = await Promise.all([
      client.from('profiles').select('id, role').order('created_at', { ascending: false }),
      client.from('home_tutor_profiles').select('id, status'),
      client.from('blood_donor_profiles').select('id, status'),
      client.from('staff_profiles').select('id, is_active'),
      client.from('service_requests').select('id, status').order('created_at', { ascending: false }),
      client.from('blood_requests').select('id, status'),
      Promise.all([
        client.from('listing_reports').select('id', { count: 'exact', head: true }).eq('status', 'open'),
        client.from('staff_profile_reports').select('id', { count: 'exact', head: true }).eq('status', 'open'),
        client.from('tutor_reports').select('id', { count: 'exact', head: true }).eq('status', 'open'),
        client.from('blood_donor_reports').select('id', { count: 'exact', head: true }).eq('status', 'open'),
      ]),
      client.from('notifications').select('id', { count: 'exact', head: true }).eq('target_role', 'admin').eq('is_read', false),
    ]);

    const profiles = profilesRes.data || [];
    const tutorsArr = (tutorsRes.data || []) as { id: string; status: string }[];
    const donorsArr = (donorsRes.data || []) as { id: string; status: string }[];
    const staffArr = (staffRes.data || []) as { id: string; is_active: boolean }[];
    const reqArr = (managedRes.data || []) as { status: ServiceRequestStatus }[];
    const bloodArr = (bloodRes.data || []) as { status: string }[];
    const [listingCount, staffCount, tutorCount, donorCount] = reportsRes.map(r => r.count ?? 0);

    const toletPendingCount = await client.from('tolet_profiles').select('id', { count: 'exact', head: true }).eq('status', 'pending_approval');

    return {
      users: profiles.length,
      pendingVerifications:
        tutorsArr.filter((t) => t.status === 'pending_approval').length +
        donorsArr.filter((d) => d.status === 'pending_approval').length +
        (toletPendingCount.count ?? 0),
      publishedTutors: tutorsArr.filter((t) => t.status === 'approved').length,
      publishedDonors: donorsArr.filter((d) => d.status === 'approved').length,
      activeStaff: staffArr.filter((s) => s.is_active).length,
      openRequests: reqArr.filter(
        (r) =>
          r.status !== 'completed' &&
          r.status !== 'cancelled' &&
          r.status !== 'rejected'
      ).length,
      bloodPending: bloodArr.filter((b) =>
        ['pending_review', 'approved'].includes(b.status)
      ).length,
      openReports: listingCount + staffCount + tutorCount + donorCount,
      unreadAdminNotifs: notifsRes.count ?? 0,
    };
  } catch {
    return mockDashboardStats();
  }
}

// ---------------------------------------------------------------------------
// User management
// ---------------------------------------------------------------------------

export async function adminFetchUsers(): Promise<AdminUserRow[]> {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase সংযুক্ত নেই; ইউজার তালিকা লোড করা যায়নি।');
  }
  const client = createClient();
  if (!client) throw new Error('Supabase ক্লায়েন্ট তৈরি করা যায়নি; আবার চেষ্টা করুন।');
  try {
    const rows: AdminUserRow[] = [];
    const pageSize = 500;
    for (let offset = 0; ; offset += pageSize) {
      const profilesRes = await client
        .from('profiles')
        .select('id,public_id,full_name,phone,email,role,status,is_verified,created_at')
        .order('created_at', { ascending: false })
        .range(offset, offset + pageSize - 1);
      if (profilesRes.error) throw new Error(profilesRes.error.message);
      const profiles = profilesRes.data ?? [];
      if (profiles.length === 0) break;

      const ids = profiles.map((profile) => profile.id);
      const [toletRes, tutorsRes, donorsRes] = await Promise.all([
        client.from('tolet_profiles').select('user_id, status').in('user_id', ids),
        client.from('home_tutor_profiles').select('user_id, status').in('user_id', ids),
        client.from('blood_donor_profiles').select('user_id, status').in('user_id', ids),
      ]);
      const relatedError = [toletRes, tutorsRes, donorsRes].find((result) => result.error)?.error;
      if (relatedError) throw new Error(relatedError.message);
      const tolet = toletRes.data ?? [];
      const tutors = tutorsRes.data ?? [];
      const donors = donorsRes.data ?? [];

      rows.push(...profiles.map((profile) => {
        const base = toCamelObject(profile as Record<string, unknown>) as unknown as UserProfile;
        const role = base.role === 'customer' || base.role === 'admin' || base.role === 'news_editor'
          ? base.role
          : 'customer';
        return {
          id: base.id,
          publicId: base.publicId,
          fullName: base.fullName || '—',
          phone: base.phone || '—',
          email: base.email,
          role,
          status: base.status,
          isVerified: base.isVerified,
          createdAt: base.createdAt,
          toletStatus: tolet.find((row) => row.user_id === profile.id)?.status ?? null,
          tutorStatus: tutors.find((row) => row.user_id === profile.id)?.status ?? null,
          donorStatus: donors.find((row) => row.user_id === profile.id)?.status ?? null,
        };
      }));
      if (profiles.length < pageSize) break;
    }
    return rows;
  } catch (err) {
    throw new Error(
      `ইউজার তালিকা লোড ব্যর্থ হয়েছে: ${err instanceof Error ? err.message : 'অজানা ত্রুটি'}`
    );
  }
}

export async function adminUpdateUserStatus(
  userId: string,
  status: UserProfile['status']
): Promise<{ success: boolean; error?: string }> {
  if (!isSupabaseConfigured) return { success: false, error: 'Supabase সংযুক্ত নেই' };
  const client = createClient();
  if (!client) return { success: false, error: 'Supabase সংযুক্ত নয়' };
  try {
    const { error } = await client.from('profiles').update({ status, updated_at: new Date().toISOString() }).eq('id', userId);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : 'ব্যর্থ' };
  }
}

// ---------------------------------------------------------------------------
// Reports moderation hub
// ---------------------------------------------------------------------------

export async function adminFetchAllReports(): Promise<AdminReportRow[]> {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase সংযুক্ত নেই; রিপোর্ট লোড করা যায়নি।');
  }
  const client = createClient();
  if (!client) throw new Error('Supabase ক্লায়েন্ট তৈরি করা যায়নি; আবার চেষ্টা করুন।');
  try {
    const [listing, staff, tutor, donor] = await Promise.all([
      client.from('listing_reports').select('*').order('created_at', { ascending: false }),
      client.from('staff_profile_reports').select('*').order('created_at', { ascending: false }),
      client.from('tutor_reports').select('*').order('created_at', { ascending: false }),
      client.from('blood_donor_reports').select('*').order('created_at', { ascending: false }),
    ]);
    const queryError = [listing, staff, tutor, donor].find((result) => result.error)?.error;
    if (queryError) throw new Error(queryError.message);
    const rows: AdminReportRow[] = [];
    for (const r of listing.data || []) {
      const c = toCamelObject(r as Record<string, unknown>) as unknown as ListingReport;
      rows.push({ id: c.id, type: 'listing', status: c.status, title: c.title ?? c.reason, reason: c.reason, createdAt: c.createdAt, relatedId: c.listingId });
    }
    for (const r of staff.data || []) {
      const c = toCamelObject(r as Record<string, unknown>) as unknown as StaffReport;
      rows.push({ id: c.id, type: 'staff', status: c.status, title: c.reason, reason: c.reason, createdAt: c.createdAt, relatedId: c.staffProfileId });
    }
    for (const r of tutor.data || []) {
      const c = toCamelObject(r as Record<string, unknown>) as unknown as TutorReport;
      rows.push({ id: c.id, type: 'tutor', status: c.status, title: c.reason, reason: c.reason, createdAt: c.createdAt, relatedId: c.tutorId });
    }
    for (const r of donor.data || []) {
      const c = toCamelObject(r as Record<string, unknown>) as unknown as BloodDonorReport;
      rows.push({ id: c.id, type: 'donor', status: c.status, title: c.reason, reason: c.reason, createdAt: c.createdAt, relatedId: c.donorProfileId });
    }
    return rows.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  } catch (err) {
    throw new Error(
      `রিপোর্ট লোড ব্যর্থ হয়েছে: ${err instanceof Error ? err.message : 'অজানা ত্রুটি'}`
    );
  }
}

export async function adminUpdateReportStatus(
  type: AdminReportRow['type'],
  id: string,
  status: AdminReportStatus
): Promise<{ success: boolean; error?: string }> {
  if (!isSupabaseConfigured) return { success: false, error: 'Supabase সংযুক্ত নেই' };
  const client = createClient();
  if (!client) return { success: false, error: 'Supabase সংযুক্ত নয়' };
  const table = ({
    listing: 'listing_reports',
    staff: 'staff_profile_reports',
    tutor: 'tutor_reports',
    donor: 'blood_donor_reports',
  } as const)[type];
  try {
    const { error } = await client.from(table).update({ status }).eq('id', id);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : 'ব্যর্থ' };
  }
}

// ---------------------------------------------------------------------------
// Tutor review moderation (admin)
// ---------------------------------------------------------------------------

export async function adminFetchTutorReviews(): Promise<(TutorReview & { tutorName?: string })[]> {
  if (!isSupabaseConfigured) throw new Error('Supabase সংযুক্ত নেই; রিভিউ লোড করা যায়নি।');
  const client = createClient();
  if (!client) throw new Error('Supabase ক্লায়েন্ট তৈরি করা যায়নি; আবার চেষ্টা করুন।');
  const { data, error } = await client
    .from('tutor_reviews')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(`রিভিউ লোড ব্যর্থ হয়েছে: ${error.message}`);
  if (!data) throw new Error('রিভিউ ডেটা পাওয়া যায়নি।');
  return data.map((row) => toCamelObject(row as Record<string, unknown>) as unknown as TutorReview);
}

export async function adminUpdateTutorReview(
  id: string,
  patch: { isPublished?: boolean }
): Promise<{ success: boolean; error?: string }> {
  if (!isSupabaseConfigured) return { success: false, error: 'Supabase সংযুক্ত নেই' };
  const client = createClient();
  if (!client) return { success: false, error: 'Supabase সংযুক্ত নয়' };
  try {
    const dbPatch: Record<string, unknown> = { updated_at: new Date().toISOString() };
    if (typeof patch.isPublished === 'boolean') dbPatch.is_published = patch.isPublished;
    const { error } = await client.from('tutor_reviews').update(dbPatch).eq('id', id);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : 'ব্যর্থ' };
  }
}

// ---------------------------------------------------------------------------
// Platform settings (single source of truth for admin-configurable values)
// ---------------------------------------------------------------------------

export async function fetchPlatformSettings(): Promise<PlatformSettings> {
  if (!isSupabaseConfigured) throw new Error('Supabase সংযুক্ত নেই; প্ল্যাটফর্ম সেটিংস লোড করা যায়নি।');
  const client = createClient();
  if (!client) throw new Error('Supabase ক্লায়েন্ট তৈরি করা যায়নি; আবার চেষ্টা করুন।');
  const { data, error } = await client.from('platform_settings').select('key, value').in('key', [
    'tolet_fee_rules',
    'service_availability',
    'notification_settings',
  ]);
  if (error) throw new Error(`প্ল্যাটফর্ম সেটিংস লোড ব্যর্থ হয়েছে: ${error.message}`);
  const parse = (key: string, fallback: unknown) => {
    const row = (data || []).find((r) => (r as Record<string, unknown>).key === key);
    if (!row) return fallback;
    const v = (row as Record<string, unknown>).value;
    return typeof v === 'object' && v !== null ? v : fallback;
  };
  return {
    toletFeeRules: (parse('tolet_fee_rules', DEFAULT_TOLET_FEE_RULES) as ToletFeeRules) || DEFAULT_TOLET_FEE_RULES,
    serviceAvailability: (parse('service_availability', {}) as Record<string, boolean>) || {},
    notificationSettings: (parse('notification_settings', {
      notifyOnRequestSubmitted: true,
      notifyOnStatusChange: true,
      notifyAdminOnNewRequest: true,
      notifyCustomerOnStatusChange: true,
    }) as PlatformSettings['notificationSettings']) || {
      notifyOnRequestSubmitted: true,
      notifyOnStatusChange: true,
      notifyAdminOnNewRequest: true,
      notifyCustomerOnStatusChange: true,
    },
  };
}

export async function savePlatformSettings(patch: {
  toletFeeRules?: ToletFeeRules;
  serviceAvailability?: Record<string, boolean>;
  notificationSettings?: PlatformSettings['notificationSettings'];
}): Promise<{ success: boolean; error?: string }> {
  if (!isSupabaseConfigured) return { success: false, error: 'Supabase সংযুক্ত নেই' };
  const client = createClient();
  if (!client) return { success: false, error: 'Supabase সংযুক্ত নয়' };
  try {
    if (patch.toletFeeRules) {
      const { error } = await client
        .from('platform_settings')
        .upsert({ key: 'tolet_fee_rules', value: patch.toletFeeRules }, { onConflict: 'key' });
      if (error) throw error;
    }
    if (patch.serviceAvailability) {
      const { error } = await client
        .from('platform_settings')
        .upsert({ key: 'service_availability', value: patch.serviceAvailability }, { onConflict: 'key' });
      if (error) throw error;
    }
    if (patch.notificationSettings) {
      const { error } = await client
        .from('platform_settings')
        .upsert({ key: 'notification_settings', value: patch.notificationSettings }, { onConflict: 'key' });
      if (error) throw error;
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : 'সংরক্ষণ ব্যর্থ' };
  }
}

// ---------------------------------------------------------------------------
// Notification hub (admin inbox)
// ---------------------------------------------------------------------------

export async function adminFetchNotifications(): Promise<NotificationItem[]> {
  if (!isSupabaseConfigured) {
    throw new Error('Supabase সংযুক্ত নেই; অ্যাডমিন নোটিফিকেশন লোড করা যায়নি।');
  }
  const client = createClient();
  if (!client) {
    throw new Error('Supabase ক্লায়েন্ট তৈরি করা যায়নি; আবার চেষ্টা করুন।');
  }

  const { data, error } = await client
    .from('notifications')
    .select('*')
    .eq('target_role', 'admin')
    .order('created_at', { ascending: false })
    .limit(100);
  if (error) throw new Error(`নোটিফিকেশন লোড ব্যর্থ হয়েছে: ${error.message}`);

  return (data ?? []).map((row) => {
    const notification = toCamelObject(row as Record<string, unknown>) as unknown as NotificationItem;
    const id = notification.relatedId;
    const links: Record<string, string> = {
      service_request: id ? `/admin/requests/${id}` : '/admin/requests',
      blood_request: '/admin/blood/donors',
      vehicle_request: '/admin/vehicle-requests',
      community_post: '/admin/posts',
      community_post_report: '/admin/reports',
      contact_message: '/admin/messages',
      listing_reports: '/admin/reports',
      staff_profile_reports: '/admin/reports',
      tutor_reports: '/admin/reports',
      blood_donor_reports: '/admin/reports',
    };
    return {
      ...notification,
      linkHref: notification.relatedType
        ? links[notification.relatedType] ?? '/admin/notifications'
        : undefined,
    };
  });
}

export async function adminMarkNotificationsRead(): Promise<{
  success: boolean;
  error?: string;
}> {
  if (!isSupabaseConfigured) {
    return { success: false, error: 'Supabase সংযুক্ত নেই; নোটিফিকেশন আপডেট করা যায়নি।' };
  }
  const client = createClient();
  if (!client) {
    return { success: false, error: 'Supabase ক্লায়েন্ট তৈরি করা যায়নি; আবার চেষ্টা করুন।' };
  }
  const { error } = await client
    .from('notifications')
    .update({ is_read: true })
    .eq('target_role', 'admin')
    .eq('is_read', false);
  if (error) return { success: false, error: `নোটিফিকেশন আপডেট ব্যর্থ হয়েছে: ${error.message}` };
  return { success: true };
}

export function reportTargetLink(type: AdminReportRow['type'], relatedId?: string): string {
  switch (type) {
    case 'listing':
      return relatedId ? `/admin/tolet/${relatedId}` : '/admin/tolet';
    case 'staff':
      return relatedId ? `/admin/services/${relatedId}` : '/admin/services';
    case 'tutor':
      return '/admin/verifications';
    case 'donor':
      return '/admin/blood/donors';
  }
}