import type { LucideIcon } from 'lucide-react';
import {
  Building2,
  Zap,
  Wrench,
  Car,
  Wind,
  GraduationCap,
  Sparkles,
  Move,
  Briefcase,
  Newspaper,
  ShoppingBag,
  Wifi,
  BookOpen,
  Stethoscope,
  ShieldCheck,
  Ambulance,
  Flame,
  HeartHandshake,
} from 'lucide-react';

/**
 * Homepage catalog — one editable source of service truth.
 *
 * `image` paths live here (not inside components) so replacing any card photo
 * later is a single-line change. Services are grouped: Electrician+Plumber and
 * Gari+Auto+CNG each live in ONE card (`chips` list the member services).
 * Emergency services intentionally have no `image` → the card renders a calm
 * forest-green glyph panel (icon + dial number) instead of a fake photo.
 */

export interface HomepageService {
  id: string;
  name: string;
  en?: string;
  text: string;
  href?: string;
  /** tel:555 style direct-dial target (emergency cards) */
  dial?: string;
  /** Man-readable number shown on the action / ghost watermark */
  number?: string;
  image?: string;
  alt?: string;
  /** object-position for the card photo (e.g. nudging a subject up/down in frame) */
  objectPosition?: string;
  chips?: string[];
  cta: string;
  pill?: string;
  /** Red text treatment for the card (blood-donor) */
  tone?: 'default' | 'red';
  featured?: boolean;
  icon: LucideIcon;
  /** Optional CSS utility for the grid cell (e.g. centering a lone last card) */
  layoutClass?: string;
  /**
   * Display order within the category. Optional so the built-in catalog keeps
   * its authored order; the admin panel writes it when an owner reorders cards.
   */
  sortOrder?: number;
}

export type CategoryTone = 'white' | 'mist' | 'dark';

export interface HomepageCategory {
  id: string;
  title: string;
  description: string;
  tone: CategoryTone;
  grid?: string;
  /** Compact cards (small square image + tight body) used when every card must sit in one desktop row */
  compact?: boolean;
  /** Dense cards — even tighter than compact (short image, tiny body) to take very little vertical space */
  dense?: boolean;
  viewAll?: { href: string; label: string };
  items: HomepageService[];
}

/* ------------------------------------------------------------------ */
/* ক্যাটাগরি ০১ — দৈনন্দিন সেবা                                          */
/* ------------------------------------------------------------------ */
export const DAILY_CATEGORY: HomepageCategory = {
  id: 'daily',
  title: 'জনপ্রিয় সেবা',
  description:
    'বাসা, মেরামত, যাতায়াত, পড়াশোনা, গৃহকর্মী — জীবন চলার কাজগুলো এখন এক পরিচিত জায়গায়।',
  tone: 'white',
  // Phones show FOUR compact tiles per row (all four must sit inside one row
  // with no sideways overflow). From `lg` upwards every card in this category
  // sits in ONE row — the desktop layout must never wrap the last card.
  grid: 'grid-cols-4 sm:grid-cols-4 md:grid-cols-4 lg:grid-cols-8',
  compact: true,
  viewAll: { href: '/services', label: 'সব সেবা দেখুন' },
  items: [
    {
      id: 'tolet',
      name: 'বাসা ভাড়া',
      en: 'To-Let',
      text: 'ফ্ল্যাট, রুম, মেস ও হোস্টেল — এলাকা আর বাজেট অনুযায়ী যাচাইকৃত তালিকা।',
      href: '/tolet',
      image: '/home.jpg',
      chips: ['ফ্যামিলি ফ্ল্যাট', 'ব্যাচেলর', 'মেস সিট'],
      cta: 'বাসা দেখুন',
      pill: 'সবচেয়ে জনপ্রিয়',
      icon: Building2,
    },
    {
      id: 'tutor',
      name: 'গৃহশিক্ষক',
      en: 'Tutoring',
      text: 'অভিজ্ঞ শিক্ষকদের কাছে স্কুল-কলেজ পড়াশোনা — এলাকাভিত্তিক, যাচাইকৃত।',
      href: '/home-tutor',
      image: '/tutor.jpg',
      chips: ['স্কুল-কলেজ', 'প্রাইভেট'],
      cta: 'শিক্ষক খুঁজুন',
      icon: GraduationCap,
    },
    {
      id: 'gari-auto-cng',
      name: 'গাড়ি, অটো ও CNG',
      en: 'Ride & Rent',
      text: 'স্থানীয় গাড়ি, অটো ও সিএনজি ভাড়া — শহরের ভেতরে সাশ্রয়ী যাতায়াত।',
      href: '/gari-auto-cng',
      image: '/carrent.png',
      chips: ['গাড়ি', 'অটো', 'CNG'],
      cta: 'সেবা দেখুন',
      pill: '৩টি সেবা',
      icon: Car,
    },
    {
      id: 'maid',
      name: 'কাজের বুয়া',
      en: 'গৃহকর্মী',
      text: 'বিশ্বস্ত, যাচাইকৃত গৃহকর্মী — গোপনীয়তা রক্ষা করে নিরাপদ বাছাই।',
      href: '/kajer-bua',
      image: '/kajerbua.jpg',
      chips: ['গৃহকর্মী'],
      cta: 'সেবা দেখুন',
      icon: Sparkles,
    },
    {
      id: 'electrician',
      name: 'ইলেকট্রিশিয়ান',
      en: 'Electrician',
      text: 'ওয়্যারিং, ফ্যান-লাইট ও সুইচ-বোর্ডের মেরামতের অনুরোধ দিন।',
      href: '/electrician',
      image: '/e&p.jpg',
      chips: ['ওয়্যারিং', 'মেরামত'],
      cta: 'সেবা নিন',
      icon: Zap,
    },
    {
      id: 'plumber',
      name: 'প্লাম্বার',
      en: 'Plumber',
      text: 'পাইপ, মোটর-পাম্প ও স্যানিটারি কাজের জন্য অনুরোধ দিন।',
      href: '/plumber',
      image: '/e&p.jpg',
      chips: ['পাইপ', 'স্যানিটারি'],
      cta: 'সেবা নিন',
      icon: Wrench,
    },
    {
      id: 'ac-fridge',
      name: 'এসি ও ফ্রিজ মেরামত',
      en: 'Cooling Repair',
      text: 'এসি সার্ভিসিং থেকে ফ্রিজ মেরামত — ঘরের শীতলতা নিয়ে থাকুন নিশ্চিত।',
      href: '/ac-fridge',
      image: '/ac.png',
      chips: ['এসি', 'ফ্রিজ'],
      cta: 'মেরামত দেখুন',
      icon: Wind,
    },
    {
      id: 'home-moving',
      name: 'বাসা পাল্টানো',
      en: 'Shifting',
      text: 'পিকআপ, লেবার টিম আর গাড়ি — বাসা বদল এখন দুশ্চিন্তামুক্ত।',
      href: '/home-moving',
      image: '/homechange.jpg',
      chips: ['শিফটিং', 'লেবার'],
      cta: 'সেবা দেখুন',
      icon: Move,
    },
  ],
};

/* ------------------------------------------------------------------ */
/* ক্যাটাগরি ০২ — কেনাকাটা, যাতায়াত ও তথ্য                               */
/* ------------------------------------------------------------------ */
export const SHOP_TRAVEL_CATEGORY: HomepageCategory = {
  id: 'shop-travel',
  title: 'প্রয়োজনীয় সব সেবা',
  description:
    'শুধু সেবা নয় — জীবনযাপন আর জ্ঞানের জায়গাগুলোও যেন হাতের কাছেই থাকে।',
  tone: 'mist',
  grid: 'grid-cols-4 sm:grid-cols-4 lg:grid-cols-7',
  compact: true,
  viewAll: { href: '/services', label: 'সব সেবা দেখুন' },
  items: [
    {
      id: 'blood-donor',
      name: 'রক্তদাতা',
      en: 'Blood Donor',
      text: 'জরুরি প্রয়োজনে স্বেচ্ছাসেবী রক্তদাতা — গোপনীয়তা রক্ষা করে সরাসরি সমন্বয়।',
      href: '/blood-donor',
      image: '/doner.jpg',
      chips: ['রক্তের গ্রুপ', 'জরুরি'],
      cta: 'দাতা খুঁজুন',
      pill: 'জরুরি',
      tone: 'red',
      icon: HeartHandshake,
    },
    {
      id: 'buy-sell',
      name: 'কেনাবেচা',
      en: 'Buy & Sell',
      text: 'ব্যবহৃত ও নতুন পণ্য — মোবাইল, আসবাব, বাইকসহ স্থানীয় কেনাবেচার পোস্ট।',
      href: '/buy-sell',
      image: '/buysell.jpg',
      chips: ['ব্যবহৃত পণ্য', 'নতুন'],
      cta: 'দেখুন',
      icon: ShoppingBag,
    },
    {
      id: 'jobs',
      name: 'চাকরি',
      en: 'Jobs',
      text: 'শহরের নতুন চাকরির বিজ্ঞপ্তি — এক জায়গায় নিয়মিত আপডেট।',
      href: '/jobs',
      image: '/job.jpg',
      chips: ['নিয়োগ বিজ্ঞপ্তি'],
      cta: 'দেখুন',
      icon: Briefcase,
    },
    {
      id: 'news',
      name: 'স্থানীয় খবর ও ঘোষণা',
      en: 'স্থানীয় খবর',
      text: 'ময়মনসিংহের প্রয়োজনীয় খবর ও ঘোষণা, অবিলম্বে।',
      href: '/news',
      image: '/news.jpg',
      chips: ['স্থানীয় খবর'],
      cta: 'দেখুন',
      icon: Newspaper,
    },
    {
      id: 'wifi',
      name: 'WiFi',
      en: 'ইন্টারনেট',
      text: 'বাসা ও ব্যবসার জন্য ইন্টারনেট সংযোগ — এলাকাভিত্তিক সেবা।',
      href: '/wifi',
      image: '/wifi.jpg',
      chips: ['ব্রডব্যান্ড', 'অফিস'],
      cta: 'দেখুন',
      icon: Wifi,
    },
    {
      id: 'coaching',
      name: 'কোচিং',
      en: 'Coaching',
      text: 'শিক্ষার্থীদের জন্য মেন্টরিং ও কোচিং ক্লাস — গড়ে তুলুন আত্মবিশ্বাস।',
      href: '/coaching',
      image: '/coutching.jpg',
      chips: ['স্কুল-কলেজ', 'মেন্টরিং'],
      cta: 'দেখুন',
      icon: BookOpen,
    },
  ],
};

/* ------------------------------------------------------------------ */
/* ক্যাটাগরি ০৩ — জরুরি ও জনসেবা                                         */
/* ------------------------------------------------------------------ */
export const EMERGENCY_CATEGORY: HomepageCategory = {
  id: 'emergency',
  title: 'ইমার্জেন্সি সেবা',
  description:
    'জরুরি মুহূর্তে সঠিক নম্বরটা খুঁজতে গিয়ে সময় নষ্ট নয় — এক ট্যাপে সরাসরি সেবায়।',
  tone: 'white',
  // Four compact tiles per row on phones and four equal columns from `lg`
  // upwards, so the four emergency cards always sit in exactly one row.
  grid: 'grid-cols-4 sm:grid-cols-4 lg:grid-cols-4',
  compact: true,
  dense: true,
  items: [
    {
      id: 'doctor',
      name: 'ডাক্তার',
      en: 'Health',
      text: 'চিকিৎসা সহায়তা ও পরামর্শের জন্য।',
      href: '/doctors',
      image: '/doctor.jpg',
      cta: 'কল করুন',
      icon: Stethoscope,
    },
    {
      id: 'police',
      name: 'পুলিশ',
      en: 'Police',
      text: 'যেকোনো জরুরি বা নিরাপত্তা প্রয়োজনে।',
      href: '/police',
      image: '/police.jpg',
      objectPosition: 'center 70%',
      cta: 'কল করুন',
      featured: true,
      icon: ShieldCheck,
    },
    {
      id: 'ambulance',
      name: 'অ্যাম্বুলেন্স',
      en: 'Ambulance',
      text: 'জরুরি রোগী পরিবহনে দ্রুত সমন্বয়।',
      href: '/ambulance',
      image: '/ambulence.jpg',
      cta: 'কল করুন',
      icon: Ambulance,
    },
    {
      id: 'fire',
      name: 'ফায়ার সার্ভিস',
      en: 'Fire Service',
      text: 'অগ্নিনির্বাপণ ও উদ্ধার কাজে সরাসরি।',
      href: '/fireservice',
      image: '/fireservice.jpg',
      cta: 'কল করুন',
      icon: Flame,
    },
  ],
};