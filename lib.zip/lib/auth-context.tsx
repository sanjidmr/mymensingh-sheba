'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  UserProfile,
  ToletProfile,
  HomeTutorProfile,
  BloodDonorProfile,
  ServiceRequestItem,
  SavedListingItem,
  NotificationItem,
} from './supabase/types';
import { createClient, isSupabaseConfigured } from './supabase/client';
import { normalizeJsonArray } from './request-data';
import { LAUNCH_SERVICES } from './services-data';
import { isSafeInternalPath, type AppRole } from './auth-routes';
import { normalizeBangladeshPhone } from './onboarding';
import { normalizeAreaName } from './area-names';
import { apiFetch } from './api-fetch';

const NOT_CONFIGURED_MESSAGE =
  'ডেটাবেজ সংযোগ নেই। Supabase কনফিগারেশন যাচাই করে আবার চেষ্টা করুন।';

function toCamelObject(row: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(row)) {
    out[key.replace(/_([a-z])/g, (_, c: string) => c.toUpperCase())] = value;
  }
  return out;
}

function toSnakeObject(obj: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(obj)) {
    out[key.replace(/[A-Z]/g, (c: string) => `_${c.toLowerCase()}`)] = value;
  }
  return out;
}

function authUserHasPassword(authUser: {
  email?: string | null;
  identities?: Array<{ provider: string }> | null;
  app_metadata?: { provider?: string; providers?: string[] };
}): boolean {
  const providers = new Set([
    ...(authUser.identities ?? []).map((identity) => identity.provider),
    ...(authUser.app_metadata?.providers ?? []),
    ...(authUser.app_metadata?.provider ? [authUser.app_metadata.provider] : []),
  ]);
  if (providers.has('email')) return true;
  if (providers.size > 0) return false;
  // When provider metadata is unavailable, fail closed for email accounts and
  // require verification rather than accidentally allowing an unverified change.
  return Boolean(authUser.email);
}

/** Builds a sensible in-app link for a notification based on its type/id. */
function notificationLink(n: {
  targetRole: string;
  relatedType?: string;
  relatedId?: string;
}): string | undefined {
  const id = n.relatedId;
  if (!id) return undefined;
  if (n.targetRole === 'admin') {
    if (n.relatedType === 'service_request') return `/admin/requests/${id}`;
    if (n.relatedType === 'blood_request') return '/admin/blood/donors';
    if (n.relatedType === 'contact_message') return `/admin/messages/${id}`;
    return '/admin/reports';
  }
  // Customer-facing decisions point at the customer dashboard: a moderation
  // verdict belongs next to the posts list, not in a generic inbox.
  if (n.relatedType === 'community_post') return '/dashboard/posts';
  if (n.relatedType === 'tolet_listing') return '/profile/tolet';
  if (n.relatedType === 'tutor_profile' || n.relatedType === 'blood_donor_profile') return '/dashboard/posts';
  if (n.relatedType === 'contact_message') return '/dashboard/messages';
  return '/profile/requests';
}

interface AuthContextType {
  user: UserProfile | null;
  toletProfile: ToletProfile | null;
  homeTutorProfile: HomeTutorProfile | null;
  bloodDonorProfile: BloodDonorProfile | null;
  requests: ServiceRequestItem[];
  savedListings: SavedListingItem[];
  savedListingsLoading: boolean;
  savedListingsError: string;
  notifications: NotificationItem[];
  notificationsError: string;
  notificationsLoading: boolean;
  isLoading: boolean;
  isAdmin: boolean;
  isConfiguredWithSupabase: boolean;
  hasPassword: boolean;
  login: (email: string, pass: string) => Promise<{ success: boolean; error?: string; role?: AppRole }>;
  signInWithGoogle: (next?: string | null) => Promise<{ success: boolean; error?: string }>;
  sendOtp: (phone: string) => Promise<{ success: boolean; error?: string }>;
  verifyOtp: (phone: string, token: string) => Promise<{ success: boolean; error?: string; role?: AppRole }>;
  register: (data: { email: string; password: string; next?: string | null }) => Promise<{
    success: boolean;
    error?: string;
    needsConfirmation?: boolean;
  }>;
  resetPassword: (phoneOrEmail: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  requestPhoneUpdate: (phone: string) => Promise<{ success: boolean; error?: string }>;
  verifyPhoneUpdate: (phone: string, token: string) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (updates: Partial<UserProfile>) => Promise<{ success: boolean; error?: string }>;
  /** Upload a new profile photo to the owner-scoped `avatars` bucket. */
  uploadAvatar: (file: File) => Promise<{ success: boolean; error?: string; url?: string }>;
  /** Change the signed-in user's password via Supabase Auth. */
  changePassword: (newPassword: string, currentPassword?: string) => Promise<{ success: boolean; error?: string }>;
  markNotificationRead: (notificationId: string) => Promise<{ success: boolean; error?: string }>;
  markNotificationsReadAll: () => Promise<{ success: boolean; error?: string }>;
  activateToletProfile: (details: Omit<ToletProfile, 'id' | 'userId' | 'createdAt' | 'updatedAt' | 'totalListingsCount' | 'status'>) => Promise<void>;
  activateHomeTutorProfile: (
    details: Omit<HomeTutorProfile, 'id' | 'userId' | 'createdAt' | 'updatedAt' | 'status'>,
    mode?: 'draft' | 'submit'
  ) => Promise<{ success: boolean; error?: string }>;
  activateBloodDonorProfile: (
    details: Omit<BloodDonorProfile, 'id' | 'userId' | 'createdAt' | 'updatedAt' | 'status'>,
    mode?: 'draft' | 'submit'
  ) => Promise<{ success: boolean; error?: string }>;
  toggleSaveItem: (item: Omit<SavedListingItem, 'id' | 'userId' | 'savedAt'>) => Promise<{ success: boolean; error?: string }>;
  createServiceRequest: (
    request: Omit<ServiceRequestItem, 'id' | 'customerId' | 'createdAt' | 'status' | 'serviceTitleBn'>
  ) => Promise<{ success: boolean; error?: string; referenceCode?: string; requestId?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [toletProfile, setToletProfile] = useState<ToletProfile | null>(null);
  const [homeTutorProfile, setHomeTutorProfile] = useState<HomeTutorProfile | null>(null);
  const [bloodDonorProfile, setBloodDonorProfile] = useState<BloodDonorProfile | null>(null);
  const [requests, setRequests] = useState<ServiceRequestItem[]>([]);
  const [savedListings, setSavedListings] = useState<SavedListingItem[]>([]);
  const [savedListingsLoading, setSavedListingsLoading] = useState(true);
  const [savedListingsError, setSavedListingsError] = useState('');
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notificationsError, setNotificationsError] = useState('');
  const [notificationsLoading, setNotificationsLoading] = useState(true);
  const [hasPassword, setHasPassword] = useState(false);
  // Keep the server render and the browser's first render identical. Whether
  // Supabase is configured is resolved after hydration in the effect below.
  const [isLoading, setIsLoading] = useState(true);

  const clearSessionState = useCallback(() => {
    setUser(null);
    setHasPassword(false);
    setToletProfile(null);
    setHomeTutorProfile(null);
    setBloodDonorProfile(null);
    setRequests([]);
    setSavedListings([]);
    setSavedListingsError('');
    setSavedListingsLoading(false);
    setNotifications([]);
    setNotificationsError('');
    setNotificationsLoading(false);
  }, []);

  const refreshUserData = useCallback(
    async (
      client: NonNullable<ReturnType<typeof createClient>>,
      userId: string,
      authUser?: {
        id: string;
        email?: string | null;
        identities?: Array<{ provider: string }> | null;
        app_metadata?: { provider?: string; providers?: string[] };
      }
    ): Promise<{ ok: boolean; blocked?: boolean; role?: AppRole }> => {
      setHasPassword(
        authUser?.id === userId ? authUserHasPassword(authUser) : false
      );
      const { data: profileData } = await client.from('profiles').select('*').eq('id', userId).single();
      if (!profileData) {
        clearSessionState();
        return { ok: false };
      }
      const profile = toCamelObject(profileData) as unknown as UserProfile;
      profile.phone = profile.phone || '';
      if (profile.email?.endsWith('@mymensinghsheba.internal')) profile.email = '';
      const rawPreferences = profileData.notification_preferences as Record<string, unknown> | null;
      profile.notificationPreferences = {
        postUpdates: rawPreferences?.post_updates !== false,
        requestUpdates: rawPreferences?.request_updates !== false,
        supportReplies: rawPreferences?.support_replies !== false,
      };
      // Account can be suspended/blocked by admin. Such users must not stay signed in.
      if (profile.status && profile.status !== 'active') {
        clearSessionState();
        return { ok: false, blocked: true };
      }
      // The verified role lives in the trusted `profiles` row, never in user
      // metadata or the email address. Everything downstream (routing, guards)
      // branches on this value.
      const role: AppRole =
        profile.role === 'admin'
          ? 'admin'
          : profile.role === 'news_editor'
            ? 'news_editor'
            : 'customer';
      setUser({ ...profile, status: profile.status || 'active' });

      const { data: toletRow } = await client.rpc('fn_my_tolet_profile').maybeSingle();
      setToletProfile(toletRow ? (toCamelObject(toletRow as Record<string, unknown>) as unknown as ToletProfile) : null);

      const { data: tutorRow } = await client.rpc('fn_my_tutor_profile').maybeSingle();
      setHomeTutorProfile(tutorRow ? (toCamelObject(tutorRow as Record<string, unknown>) as unknown as HomeTutorProfile) : null);

      const { data: donorRow } = await client.rpc('fn_my_donor_profile').maybeSingle();
      setBloodDonorProfile(donorRow ? (toCamelObject(donorRow as Record<string, unknown>) as unknown as BloodDonorProfile) : null);

      const { data: requestRows } = await client
        .from('service_requests')
        .select('*')
        .eq('customer_id', userId)
        .order('created_at', { ascending: false });
      const mappedRequests = (requestRows ?? []).map((row: Record<string, unknown>) => {
        const camel = toCamelObject(row) as unknown as ServiceRequestItem;
        camel.movingItems = normalizeJsonArray(camel.movingItems).filter(
          (item): item is NonNullable<ServiceRequestItem['movingItems']>[number] =>
            Boolean(item) &&
            typeof item === 'object' &&
            typeof (item as Record<string, unknown>).id === 'string' &&
            typeof (item as Record<string, unknown>).labelBn === 'string'
        );
        camel.photoUrls = normalizeJsonArray(camel.photoUrls).filter(
          (url): url is string => typeof url === 'string'
        );
        const service = LAUNCH_SERVICES.find((s) => s.slug === camel.serviceSlug);
        camel.serviceTitleBn = service?.nameBn || camel.serviceSlug;
        if (!camel.profileTitleBn) {
          camel.profileTitleBn =
            ((camel as unknown as Record<string, unknown>).profileTitle as string) || undefined;
        }
        return camel;
      });
      setRequests(mappedRequests);

      setSavedListingsLoading(true);
      const { data: savedRows, error: savedError } = await client
        .from('saved_items')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (savedError) {
        setSavedListings([]);
        setSavedListingsError(`সংরক্ষিত পোস্ট লোড করা যায়নি: ${savedError.message}`);
      } else {
        setSavedListingsError('');
        setSavedListings(
          (savedRows ?? []).flatMap((row: Record<string, unknown>) => {
            const camel = toCamelObject(row) as Record<string, unknown>;
            const itemType = camel.itemType;
            const itemId = String(camel.itemId ?? '');
            if (
              (itemType !== 'tolet' && itemType !== 'tutor' && itemType !== 'market' && itemType !== 'service') ||
              !itemId
            ) {
              return [];
            }
            return [{
              id: String(camel.id),
              userId: String(camel.userId),
              itemType,
              itemId,
              title: '',
              areaName: '',
              linkHref:
                itemType === 'tolet'
                  ? `/tolet/${itemId}`
                  : itemType === 'tutor'
                    ? `/home-tutor/${itemId}`
                    : itemType === 'market'
                      ? `/buy-sell/${itemId}`
                      : '/services',
              savedAt: String(camel.createdAt),
            }];
          })
        );
      }
      setSavedListingsLoading(false);

      // Notifications: personal ones plus (for admins) the admin hub rows.
      setNotificationsLoading(true);
      const isAdminUser = profile.role === 'admin';
      const { data: personalNotifs, error: personalNotifError } = await client
        .from('notifications')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(50);
      const { data: adminNotifs, error: adminNotifError } = isAdminUser
        ? await client
            .from('notifications')
            .select('*')
            .eq('target_role', 'admin')
            .order('created_at', { ascending: false })
            .limit(50)
        : { data: [], error: null };
      if (personalNotifError || adminNotifError) {
        setNotifications([]);
        setNotificationsError(
          `নোটিফিকেশন লোড করা যায়নি: ${personalNotifError?.message ?? adminNotifError?.message}`
        );
        setNotificationsLoading(false);
        // The profile itself loaded fine — a transient notifications failure must
        // not sign the user out or make the caller forget their verified role.
        return { ok: true, role };
      }
      setNotificationsError('');
      const merged: NotificationItem[] = [...personalNotifs, ...adminNotifs]
        .map((row) => {
          const c = toCamelObject(row as Record<string, unknown>) as unknown as NotificationItem;
          c.linkHref = notificationLink(c);
          return c;
        })
        .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
        .slice(0, 50);
      setNotifications(merged);
      setNotificationsLoading(false);
      return { ok: true, role };
    },
    [clearSessionState]
  );

  useEffect(() => {
    if (!isSupabaseConfigured) {
      queueMicrotask(() => setIsLoading(false));
      return;
    }
    const client = createClient();
    if (!client) {
      return;
    }
    client.auth.getSession().then(async ({ data }) => {
      if (data.session?.user) {
        const res = await refreshUserData(client, data.session.user.id, data.session.user);
        if (res && !res.ok) {
          await client.auth.signOut();
        }
      }
      setIsLoading(false);
    }).catch(() => setIsLoading(false));
    const { data: subscription } = client.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        refreshUserData(client, session.user.id, session.user);
      } else {
        clearSessionState();
      }
    });
    return () => subscription.subscription.unsubscribe();
  }, [refreshUserData, clearSessionState]);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      if (!isSupabaseConfigured) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const client = createClient();
      if (!client) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const { data, error } = await client.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password: pass,
      });
      if (error) {
        return { success: false, error: error.message };
      }
      if (data.user) {
        const res = await refreshUserData(client, data.user.id, data.user);
        if (res && !res.ok) {
          await client.auth.signOut();
          return {
            success: false,
            error: res.blocked
              ? 'আপনার অ্যাকাউন্টটি স্থগিত বা বন্ধ। সহায়তার জন্য প্রশাসকের সঙ্গে যোগাযোগ করুন।'
              : 'প্রোফাইল তথ্য লোড করা যায়নি। আবার চেষ্টা করুন।',
          };
        }
        return { success: true, role: res?.role ?? 'customer' };
      }
      return { success: false, error: 'লগইন সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।' };
    } catch (err: unknown) {
      return { success: false, error: err instanceof Error ? err.message : 'লগইন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।' };
    } finally {
      setIsLoading(false);
    }
  };

  const signInWithGoogle = async (next?: string | null) => {
    if (!isSupabaseConfigured) {
      return { success: false, error: NOT_CONFIGURED_MESSAGE };
    }
    const client = createClient();
    if (!client) {
      return { success: false, error: NOT_CONFIGURED_MESSAGE };
    }
    const target = isSafeInternalPath(next) ? next : '/profile';
    const callback = new URL('/auth/callback', window.location.origin);
    callback.searchParams.set('next', target);
    const { error } = await client.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: callback.toString() },
    });
    return error
      ? { success: false, error: error.message }
      : { success: true };
  };

  const sendOtp = async (phone: string) => {
    setIsLoading(true);
    try {
      if (!isSupabaseConfigured) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const client = createClient();
      if (!client) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const { error } = await client.auth.signInWithOtp({ phone });
      if (error) {
        return { success: false, error: error.message };
      }
      return { success: true };
    } finally {
      setIsLoading(false);
    }
  };

  const requestPhoneUpdate = async (phone: string) => {
    if (!user) return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const normalized = normalizeBangladeshPhone(phone);
    if (!normalized) return { success: false, error: 'সঠিক বাংলাদেশি মোবাইল নম্বর লিখুন।' };
    const client = createClient();
    if (!client) return { success: false, error: NOT_CONFIGURED_MESSAGE };

    const { error } = await client.auth.updateUser({ phone: normalized.international });
    return error
      ? { success: false, error: `যাচাইকরণ কোড পাঠানো যায়নি: ${error.message}` }
      : { success: true };
  };

  const verifyPhoneUpdate = async (phone: string, token: string) => {
    if (!user) return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const normalized = normalizeBangladeshPhone(phone);
    if (!normalized) return { success: false, error: 'সঠিক বাংলাদেশি মোবাইল নম্বর লিখুন।' };
    if (!/^\d{6}$/.test(token.trim())) return { success: false, error: '৬ সংখ্যার যাচাইকরণ কোড লিখুন।' };
    const client = createClient();
    if (!client) return { success: false, error: NOT_CONFIGURED_MESSAGE };

    const { data, error } = await client.auth.verifyOtp({
      phone: normalized.international,
      token: token.trim(),
      type: 'phone_change',
    });
    if (error) return { success: false, error: `নম্বর যাচাই করা যায়নি: ${error.message}` };
    if (!data.user) return { success: false, error: 'নম্বর যাচাই সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।' };

    const { error: profileError } = await client
      .from('profiles')
      .update({ phone: normalized.local, updated_at: new Date().toISOString() })
      .eq('id', data.user.id);
    if (profileError) {
      return { success: false, error: `যাচাইকৃত নম্বর প্রোফাইলে সংরক্ষণ করা যায়নি: ${profileError.message}` };
    }

    const refreshed = await refreshUserData(client, data.user.id, data.user);
    if (!refreshed?.ok) {
      return { success: false, error: 'নম্বর সংরক্ষিত হয়েছে, তবে প্রোফাইল রিফ্রেশ করা যায়নি। পৃষ্ঠা রিলোড করুন।' };
    }
    return { success: true };
  };

  const verifyOtp = async (phone: string, token: string) => {
    setIsLoading(true);
    try {
      if (!isSupabaseConfigured) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const client = createClient();
      if (!client) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const { data, error } = await client.auth.verifyOtp({ phone, token, type: 'sms' });
      if (error) {
        return { success: false, error: error.message };
      }
      if (data.user) {
        const res = await refreshUserData(client, data.user.id, data.user);
        if (res && !res.ok) {
          await client.auth.signOut();
          return {
            success: false,
            error: res.blocked
              ? 'আপনার অ্যাকাউন্টটি স্থগিত বা বন্ধ। সহায়তার জন্য প্রশাসকের সঙ্গে যোগাযোগ করুন।'
              : 'প্রোফাইল তথ্য লোড করা যায়নি। আবার চেষ্টা করুন।',
          };
        }
        return { success: true, role: res?.role ?? 'customer' };
      }
      return { success: false, error: 'যাচাইকরণ সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।' };
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: { email: string; password: string; next?: string | null }) => {
    setIsLoading(true);
    try {
      if (!isSupabaseConfigured) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const client = createClient();
      if (!client) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const email = data.email.trim().toLowerCase();
      const emailRedirectTo = new URL('/auth/callback', window.location.origin);
      const requestedTarget = isSafeInternalPath(data.next) ? data.next : '/profile';
      emailRedirectTo.searchParams.set('next', requestedTarget);
      const { data: signUpData, error } = await client.auth.signUp({
        email,
        password: data.password,
        options: {
          emailRedirectTo: emailRedirectTo.toString(),
          data: { email, full_name: email.split('@')[0] },
        },
      });
      if (error) {
        return { success: false, error: error.message };
      }
      if (!signUpData.user) {
        return { success: false, error: 'অ্যাকাউন্ট তৈরি করা যায়নি। আবার চেষ্টা করুন।' };
      }

      if (signUpData.session) {
        const res = await refreshUserData(client, signUpData.user.id, signUpData.user);
        if (!res?.ok) {
          await client.auth.signOut();
          return {
            success: false,
            error: res?.blocked
              ? 'আপনার অ্যাকাউন্টটি স্থগিত বা বন্ধ। সহায়তার জন্য প্রশাসকের সঙ্গে যোগাযোগ করুন।'
              : 'প্রোফাইল তথ্য লোড করা যায়নি। আবার চেষ্টা করুন।',
          };
        }
        return { success: true };
      }

      // Supabase does not issue a session until its required email confirmation
      // is completed. The callback exchanges that confirmation code and signs
      // the user in; do not attempt a second password login here.
      if (signUpData.user.confirmation_sent_at) {
        return { success: true, needsConfirmation: true };
      }

      return {
        success: false,
        error: 'এই ইমেইল দিয়ে অ্যাকাউন্ট তৈরি করা যায়নি। ইমেইলটি আগে ব্যবহার হয়ে থাকলে পাসওয়ার্ড পুনরুদ্ধার করুন।',
      };
    } catch (err: unknown) {
      return { success: false, error: err instanceof Error ? err.message : 'নিবন্ধন ব্যর্থ হয়েছে। আবার চেষ্টা করুন।' };
    } finally {
      setIsLoading(false);
    }
  };

  const resetPassword = async (phoneOrEmail: string) => {
    setIsLoading(true);
    try {
      if (!isSupabaseConfigured) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const client = createClient();
      if (!client) {
        return { success: false, error: NOT_CONFIGURED_MESSAGE };
      }
      const email = phoneOrEmail.includes('@') ? phoneOrEmail : `${phoneOrEmail}@mymensinghsheba.internal`;
      // Route the recovery link through the existing code-exchange callback so
      // the email opens a validated session, then land on the password form.
      const redirectTo = new URL('/auth/callback?next=/reset-password', window.location.origin).toString();
      const { error } = await client.auth.resetPasswordForEmail(email, { redirectTo });
      if (error) {
        return { success: false, error: error.message };
      }
      return { success: true };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      if (isSupabaseConfigured) {
        const client = createClient();
        if (!client) throw new Error('Supabase সংযোগ তৈরি করা যায়নি।');
        const { error } = await client.auth.signOut();
        if (error) throw new Error(`লগআউট করা যায়নি: ${error.message}`);
      }
      clearSessionState();
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    if (!user) return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase সংযুক্ত নেই; তথ্য সংরক্ষণ করা যায়নি।' };
    }
    const client = createClient();
    if (!client) {
      return { success: false, error: 'ডেটাবেজ সংযোগ তৈরি করা যায়নি; আবার চেষ্টা করুন।' };
    }

    if (updates.phone !== undefined && updates.phone.trim() && !normalizeBangladeshPhone(updates.phone)) {
      return { success: false, error: 'সঠিক ১১-ডিজিটের বাংলাদেশি মোবাইল নম্বর লিখুন।' };
    }
    if (updates.fullName !== undefined && updates.fullName.trim().length < 2) {
      return { success: false, error: 'নাম কমপক্ষে ২ অক্ষরের লিখুন।' };
    }
    if (updates.bio !== undefined && updates.bio.length > 300) {
      return { success: false, error: 'পরিচিতি ৩০০ অক্ষরের মধ্যে লিখুন।' };
    }
    const primaryAreaId = updates.primaryAreaId === undefined
      ? user.primaryAreaId
      : normalizeAreaName(updates.primaryAreaId || '');
    if (updates.primaryAreaId !== undefined && (!primaryAreaId || primaryAreaId.length > 100)) {
      return { success: false, error: 'আপনার এলাকার নাম লিখুন (সর্বোচ্চ ১০০ অক্ষর)।' };
    }

    const normalizedPhone = updates.phone === undefined
      ? user.phone
      : normalizeBangladeshPhone(updates.phone)?.local ?? '';
    const updated = {
      ...user,
      ...updates,
      primaryAreaId,
      phone: normalizedPhone,
      updatedAt: new Date().toISOString(),
    };
    const notificationPreferences = updates.notificationPreferences
      ? {
          post_updates: updates.notificationPreferences.postUpdates,
          request_updates: updates.notificationPreferences.requestUpdates,
          support_replies: updates.notificationPreferences.supportReplies,
        }
      : undefined;
    const { error } = await client
      .from('profiles')
      .update({
        full_name: updated.fullName,
        phone: updated.phone || null,
        email: updated.email || null,
        avatar_url: updated.avatarUrl || null,
        bio: updated.bio || null,
        primary_area_id: updated.primaryAreaId,
        emergency_contact: updated.emergencyContact || null,
        ...(notificationPreferences ? { notification_preferences: notificationPreferences } : {}),
        updated_at: updated.updatedAt,
      })
      .eq('id', user.id);
    if (error) {
      return { success: false, error: `প্রোফাইল সংরক্ষণ ব্যর্থ হয়েছে: ${error.message}` };
    }

    setUser(updated);
    return { success: true };
  };

  /** Uploads an avatar to the caller's own folder in the public avatars bucket. */
  const uploadAvatar = async (file: File) => {
    if (!user) return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    const avatarExtensions: Record<string, string> = {
      'image/jpeg': 'jpg',
      'image/png': 'png',
      'image/webp': 'webp',
    };
    const extension = avatarExtensions[file.type];
    if (!extension) {
      return { success: false, error: 'শুধু JPG, PNG বা WebP ছবি আপলোড করুন।' };
    }
    if (file.size === 0) return { success: false, error: 'খালি ফাইল আপলোড করা যাবে না।' };
    if (file.size > 5 * 1024 * 1024) {
      return { success: false, error: 'ছবির আকার সর্বোচ্চ ৫ MB হতে পারবে।' };
    }
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const client = createClient();
    if (!client) return { success: false, error: NOT_CONFIGURED_MESSAGE };

    const uniqueId =
      typeof crypto !== 'undefined' && 'randomUUID' in crypto
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const path = `${user.id}/avatar-${uniqueId}.${extension}`;
    const { error } = await client.storage.from('avatars').upload(path, file, {
      contentType: file.type,
      upsert: false,
    });
    if (error) return { success: false, error: `ছবি আপলোড ব্যর্থ হয়েছে: ${error.message}` };

    const { data } = client.storage.from('avatars').getPublicUrl(path);
    if (!data.publicUrl) return { success: false, error: 'ছবির ঠিকানা তৈরি করা যায়নি।' };
    const profileResult = await updateProfile({ avatarUrl: data.publicUrl });
    if (!profileResult.success) {
      const { error: cleanupError } = await client.storage.from('avatars').remove([path]);
      if (cleanupError) {
        return {
          success: false,
          error: `${profileResult.error || 'প্রোফাইলে ছবি সংরক্ষণ ব্যর্থ হয়েছে।'} ছবিটি আপলোড হয়েছে, কিন্তু পরিষ্কার করা যায়নি: ${cleanupError.message}`,
        };
      }
      return profileResult;
    }
    return { success: true, url: data.publicUrl };
  };

  /** Sets a new password for the current authenticated session. */
  const changePassword = async (newPassword: string, currentPassword?: string) => {
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const client = createClient();
    if (!client) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    if (newPassword.length < 6) {
      return { success: false, error: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।' };
    }
    const { data: authData, error: authError } = await client.auth.getUser();
    const authUser = authData.user;
    if (authError || !authUser) {
      return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    }
    const passwordExists = authUserHasPassword(authUser);
    if (passwordExists) {
      if (!currentPassword) {
        return { success: false, error: 'বর্তমান পাসওয়ার্ড লিখুন।' };
      }
      if (!authUser.email) {
        return { success: false, error: 'বর্তমান পাসওয়ার্ড যাচাই করা যাচ্ছে না।' };
      }
      const { error: verificationError } = await client.auth.signInWithPassword({
        email: authUser.email,
        password: currentPassword,
      });
      if (verificationError) {
        return { success: false, error: 'বর্তমান পাসওয়ার্ড সঠিক নয়।' };
      }
    }
    const { error } = await client.auth.updateUser({ password: newPassword });
    if (error) return { success: false, error: `পাসওয়ার্ড সংরক্ষণ করা যায়নি: ${error.message}` };
    setHasPassword(true);
    return { success: true };
  };

  const activateToletProfile = async (
    details: Omit<ToletProfile, 'id' | 'userId' | 'createdAt' | 'updatedAt' | 'totalListingsCount' | 'status'>
  ) => {
    if (!user) return;
    const newProf: ToletProfile = {
      id: `tolet-${Date.now()}`,
      userId: user.id,
      status: 'pending_approval',
      totalListingsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      ...details,
    };
    setToletProfile(newProf);
    if (isSupabaseConfigured) {
      const client = createClient();
      if (client) {
        await client
          .from('tolet_profiles')
          .upsert(
            { ...toSnakeObject(details as Record<string, unknown>), user_id: user.id, status: 'pending_approval' },
            { onConflict: 'user_id' }
          );
      }
    }
  };

  const activateHomeTutorProfile = async (
    details: Omit<HomeTutorProfile, 'id' | 'userId' | 'createdAt' | 'updatedAt' | 'status'>,
    mode: 'draft' | 'submit' = 'submit'
  ): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'প্রোফাইল সংরক্ষণ করতে লগইন করুন।' };
    const validChoices = (items: string[]) =>
      items.length <= 30 &&
      items.every((item) => item.trim().length > 0 && item.trim().length <= 60) &&
      new Set(items.map((item) => item.trim().toLocaleLowerCase())).size === items.length;
    if (!validChoices(details.preferredClasses) || !validChoices(details.preferredSubjects)) {
      return { success: false, error: 'শ্রেণি ও বিষয়ের তথ্য সঠিকভাবে লিখুন।' };
    }
    if (!Number.isInteger(details.expectedSalary) || details.expectedSalary < 0 ||
      !Number.isInteger(details.daysPerWeek) || details.daysPerWeek < 1 || details.daysPerWeek > 7) {
      return { success: false, error: 'প্রত্যাশিত বেতন বা সপ্তাহে পড়ানোর দিনের সংখ্যা সঠিক নয়।' };
    }
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const client = createClient();
    if (!client) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    // Editing an already-published tutor keeps them published; otherwise the edit
    // goes back into review (draft/pending_approval). Approved/Rejected status is
    // always admin-owned and never sent from the client.
    const { data: existing, error: lookupError } = await client
      .from('home_tutor_profiles')
      .select('id, status')
      .eq('user_id', user.id)
      .maybeSingle();
    if (lookupError) return { success: false, error: `প্রোফাইল পড়া যায়নি: ${lookupError.message}` };
    const keepApproved = existing?.status === 'approved';
    const status = keepApproved ? 'approved' : mode === 'draft' ? 'draft' : 'pending_approval';
    const payload: Record<string, unknown> = {
      user_id: user.id,
      full_name: details.fullName,
      gender: details.gender,
      institution: details.institution,
      department: details.department,
      qualification: details.qualification,
      experience_years: details.experienceYears,
      preferred_areas: details.preferredAreas,
      preferred_classes: details.preferredClasses,
      preferred_subjects: details.preferredSubjects,
      expected_salary: details.expectedSalary,
      expected_salary_min: details.expectedSalary,
      expected_salary_max: details.expectedSalary,
      days_per_week: details.daysPerWeek,
      bio: details.bio || null,
      student_id_card_url: details.studentIdCardUrl || null,
      nid_number: details.nidNumber || null,
      private_phone: details.privatePhone,
      teaching_mode: details.teachingMode,
      availability: details.availability,
      profile_photo_url: details.profilePhotoUrl || null,
      educations: details.educations ?? [],
      status,
    };
    // The trigger permits keeping an existing approved profile approved but
    // prevents every owner-initiated transition into a guarded status.
    const result = existing
      ? await client
          .from('home_tutor_profiles')
          .update(payload)
          .eq('id', existing.id)
          .select('id, created_at, updated_at')
          .single()
      : await client
          .from('home_tutor_profiles')
          .insert(payload)
          .select('id, created_at, updated_at')
          .single();
    if (result.error || !result.data) {
      return {
        success: false,
        error: `প্রোফাইল সংরক্ষণ ব্যর্থ হয়েছে: ${result.error?.message || 'সংরক্ষিত প্রোফাইল ফেরত পাওয়া যায়নি।'}`,
      };
    }
    const newProf: HomeTutorProfile = {
      id: result.data.id,
      userId: user.id,
      status,
      createdAt: result.data.created_at,
      updatedAt: result.data.updated_at,
      ...details,
    };
    setHomeTutorProfile(newProf);
    return { success: true };
  };

  const activateBloodDonorProfile = async (
    details: Omit<BloodDonorProfile, 'id' | 'userId' | 'createdAt' | 'updatedAt' | 'status'>,
    mode: 'draft' | 'submit' = 'submit'
  ): Promise<{ success: boolean; error?: string }> => {
    if (!user) return { success: false, error: 'প্রোফাইল সংরক্ষণ করতে লগইন করুন।' };
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const client = createClient();
    if (!client) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    // Editing an already-published donor keeps them published; otherwise the edit
    // goes back into review (pending_approval). Approved/Rejected/Suspended status
    // is always admin-owned and never sent from the client.
    const { data: existing, error: lookupError } = await client
      .from('blood_donor_profiles')
      .select('id, status')
      .eq('user_id', user.id)
      .maybeSingle();
    if (lookupError) return { success: false, error: `প্রোফাইল পড়া যায়নি: ${lookupError.message}` };
    const keepApproved = existing?.status === 'approved';
    const status = keepApproved ? 'approved' : mode === 'draft' ? 'draft' : 'pending_approval';
    const payload: Record<string, unknown> = {
      user_id: user.id,
      full_name: details.fullName,
      blood_group: details.bloodGroup,
      area_id: details.areaId,
      gender: details.gender,
      birth_year: details.birthYear ?? null,
      weight_kg: details.weightKg ?? null,
      is_available: details.isAvailable,
      last_donation_date: details.lastDonationDate || null,
      donation_count: details.donationCount,
      // Private donor contact and verification are never public or owner-writable.
      private_phone: details.privatePhone,
      intro: details.intro || null,
      profile_photo_url: details.profilePhotoUrl || null,
      // Owner-controlled visibility of the "রক্তদানের বর্তমান প্রস্তুতি" panel on
      // the public card. Defaults to hidden so a donor who never chose to show it
      // is never published as if they had.
      show_readiness: details.showReadiness ?? false,
      status,
    };
    const result = existing
      ? await client
          .from('blood_donor_profiles')
          .update(payload)
          .eq('id', existing.id)
          .select('id, created_at, updated_at')
          .single()
      : await client
          .from('blood_donor_profiles')
          .insert(payload)
          .select('id, created_at, updated_at')
          .single();
    if (result.error || !result.data) {
      return {
        success: false,
        error: `প্রোফাইল সংরক্ষণ ব্যর্থ হয়েছে: ${result.error?.message || 'সংরক্ষিত প্রোফাইল ফেরত পাওয়া যায়নি।'}`,
      };
    }
    const newProf: BloodDonorProfile = {
      id: result.data.id,
      userId: user.id,
      status,
      createdAt: result.data.created_at,
      updatedAt: result.data.updated_at,
      ...details,
    };
    setBloodDonorProfile(newProf);
    return { success: true };
  };

  const toggleSaveItem = async (item: Omit<SavedListingItem, 'id' | 'userId' | 'savedAt'>) => {
    if (!user) return { success: false, error: 'সংরক্ষিত পোস্টে পরিবর্তনের আগে লগইন করুন।' };
    if (!isSupabaseConfigured) return { success: false, error: NOT_CONFIGURED_MESSAGE };
    const client = createClient();
    if (!client) return { success: false, error: 'ডেটাবেজ সংযোগ তৈরি করা যায়নি।' };
    const itemId = item.itemId || item.linkHref.split('/').filter(Boolean).pop();
    if (!itemId) return { success: false, error: 'পোস্টের পরিচিতি পাওয়া যায়নি।' };
    const existing = savedListings.find((saved) => saved.itemType === item.itemType && saved.itemId === itemId);
    if (existing) {
      const { error } = await client
        .from('saved_items')
        .delete()
        .eq('id', existing.id)
        .eq('user_id', user.id);
      if (error) return { success: false, error: `সংরক্ষিত পোস্ট সরানো যায়নি: ${error.message}` };
      setSavedListings((previous) => previous.filter((saved) => saved.id !== existing.id));
    } else {
      const { data, error } = await client
        .from('saved_items')
        .insert({ user_id: user.id, item_type: item.itemType, item_id: itemId })
        .select('id, created_at')
        .single();
      if (error || !data) {
        return { success: false, error: `পোস্ট সংরক্ষণ করা যায়নি: ${error?.message ?? 'সংরক্ষিত পোস্ট ফেরত পাওয়া যায়নি।'}` };
      }
      setSavedListings((previous) => [{
        ...item,
        itemId,
        id: data.id,
        userId: user.id,
        savedAt: data.created_at,
      }, ...previous]);
    }
    return { success: true };
  };

  const markNotificationRead = async (notificationId: string) => {
    if (!user) return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    if (!/^[0-9a-f-]{36}$/i.test(notificationId)) {
      return { success: false, error: 'নোটিফিকেশন আইডি সঠিক নয়।' };
    }
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase সংযুক্ত নেই; নোটিফিকেশন আপডেট করা যায়নি।' };
    }
    const client = createClient();
    if (!client) return { success: false, error: 'ডেটাবেজ সংযোগ তৈরি করা যায়নি।' };

    let query = client
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId)
      .eq('is_read', false);
    query = user.role === 'admin'
      ? query.or(`user_id.eq.${user.id},target_role.eq.admin`)
      : query.eq('user_id', user.id).eq('target_role', 'customer');
    const { error } = await query;
    if (error) return { success: false, error: `নোটিফিকেশন আপডেট ব্যর্থ হয়েছে: ${error.message}` };
    setNotifications((previous) =>
      previous.map((notification) =>
        notification.id === notificationId ? { ...notification, isRead: true } : notification
      )
    );
    return { success: true };
  };

  const markNotificationsReadAll = async () => {
    if (!user) return { success: false, error: 'আপনাকে আগে লগইন করতে হবে।' };
    if (!isSupabaseConfigured) {
      return { success: false, error: 'Supabase সংযুক্ত নেই; নোটিফিকেশন আপডেট করা যায়নি।' };
    }
    const client = createClient();
    if (!client) {
      return { success: false, error: 'ডেটাবেজ সংযোগ তৈরি করা যায়নি; আবার চেষ্টা করুন।' };
    }

    // Personal rows are scoped to the signed-in user; admin hub rows are only
    // included for a verified admin session and remain protected by RLS.
    const personalPromise = client
      .from('notifications')
      .update({ is_read: true })
      .eq('user_id', user.id)
      .eq('is_read', false);
    const adminPromise =
      user.role === 'admin'
        ? client
            .from('notifications')
            .update({ is_read: true })
            .eq('target_role', 'admin')
            .eq('is_read', false)
        : Promise.resolve({ error: null });
    const [personalResult, adminResult] = await Promise.all([personalPromise, adminPromise]);
    if (personalResult.error || adminResult.error) {
      return {
        success: false,
        error: `নোটিফিকেশন আপডেট ব্যর্থ হয়েছে: ${personalResult.error?.message ?? adminResult.error?.message}`,
      };
    }
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    return { success: true };
  };

  const createServiceRequest = async (
    requestData: Omit<
      ServiceRequestItem,
      'id' | 'customerId' | 'createdAt' | 'status' | 'serviceTitleBn'
    >
  ): Promise<{ success: boolean; error?: string; referenceCode?: string; requestId?: string }> => {
    if (!user) {
      return { success: false, error: 'অনুরোধ পাঠাতে লগইন করতে হবে।' };
    }

    // Write first, then reflect it. A request that failed to persist must not
    // appear in the customer's list as if it had been filed — and callers rely
    // on this result to know whether the submission was really recorded.
    let requestId: string | undefined;
    let referenceCode: string | undefined;
    if (isSupabaseConfigured) {
      let response: Response;
      try {
        response = await apiFetch('/api/order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            service_type: requestData.serviceSlug,
            service_slug: requestData.serviceSlug,
            service_label: requestData.serviceType || null,
            area_id: requestData.areaId,
            address_line: requestData.addressLine,
            contact_name: requestData.contactName,
            contact_phone: requestData.contactPhone,
            preferred_date: requestData.preferredDate || null,
            preferred_time: requestData.preferredTime || null,
            details: requestData.details || null,
            profile_id: requestData.profileId || null,
            profile_title: requestData.profileTitleBn || null,
            attachment_url: requestData.attachmentUrl || null,
            pickup_area_id: requestData.pickupAreaId || null,
            destination_area_id: requestData.destinationAreaId || null,
            pickup_address: requestData.pickupAddress || null,
            destination_address: requestData.destinationAddress || null,
            pickup_floor: requestData.pickupFloor || null,
            destination_floor: requestData.destinationFloor || null,
            has_lift: requestData.hasLift || false,
            parking_info: requestData.parkingInfo || null,
            moving_items: requestData.movingItems ?? [],
            photo_urls: requestData.photoUrls ?? [],
          }),
        });
      } catch {
        return { success: false, error: 'অনুরোধ সংরক্ষণ করা যায়নি। ইন্টারনেট সংযোগ যাচাই করে আবার চেষ্টা করুন।' };
      }
      let result: {
        success?: boolean;
        requestId?: string;
        reference?: string;
        error?: string;
      };
      try {
        result = await response.json() as typeof result;
      } catch {
        return { success: false, error: 'সার্ভার থেকে সঠিক উত্তর পাওয়া যায়নি। আবার চেষ্টা করুন।' };
      }
      if (!response.ok || !result.success || !result.requestId) {
        return { success: false, error: result.error || 'অনুরোধ সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।' };
      }
      requestId = result.requestId;
      referenceCode = result.reference;
    }

    const newReq: ServiceRequestItem = {
      ...requestData,
      id: requestId ?? `req-${Date.now()}`,
      referenceCode,
      customerId: user.id,
      status: 'new',
      serviceTitleBn:
        LAUNCH_SERVICES.find((s) => s.slug === requestData.serviceSlug)?.nameBn ||
        requestData.serviceSlug,
      createdAt: new Date().toISOString(),
    };
    setRequests((prev) => [newReq, ...prev]);
    return { success: true, requestId, referenceCode };
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        toletProfile,
        homeTutorProfile,
        bloodDonorProfile,
        requests,
        savedListings,
        savedListingsLoading,
        savedListingsError,
        notifications,
        notificationsError,
        notificationsLoading,
        isLoading,
        isAdmin: user?.role === 'admin',
        isConfiguredWithSupabase: isSupabaseConfigured,
        hasPassword,
        login,
        signInWithGoogle,
        sendOtp,
        verifyOtp,
        register,
        resetPassword,
        logout,
        requestPhoneUpdate,
        verifyPhoneUpdate,
        updateProfile,
        uploadAvatar,
        changePassword,
        markNotificationRead,
        markNotificationsReadAll,
        activateToletProfile,
        activateHomeTutorProfile,
        activateBloodDonorProfile,
        toggleSaveItem,
        createServiceRequest,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
