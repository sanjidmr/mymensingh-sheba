/**
 * Shared types + per-category configuration for the newer service pages.
 *
 * Two families live here:
 *
 *  1. `ServiceListing` — the ADMIN-curated directories (coaching, wifi, bus,
 *     vehicle). One table, one CRUD path, four category configs. Only admins
 *     write these; everyone else reads and filters.
 *  2. `CommunityPost` — the USER-authored content (news, jobs, buy-sell).
 *     Authors manage their own rows; they land in `pending` and an admin
 *     approves them.
 *
 * Everything else in this file is configuration: the copy, the taxonomy and
 * the card layout each page needs. Keeping it declarative is what stops eight
 * new pages from drifting into eight different-looking templates.
 *
 * HONESTY RULE (applies to every category below): the taxonomy here is
 * vocabulary (class names, subject names, area names, job types) — NOT
 * businesses, prices or phone numbers. Any real provider, price or local
 * number only ever comes from the database, entered by an admin. Nothing in
 * this file is seeded into the UI as content.
 */
import { getAllMCCAreas, getAreaById } from './locations';
import { uniqueAreaNames } from './area-names';

// ---------------------------------------------------------------------------
// Admin-curated listings
// ---------------------------------------------------------------------------

export type ServiceCategory = 'coaching' | 'wifi' | 'bus' | 'vehicle';

/** The two categories a signed-in customer may create and manage. */
export type CustomerServiceCategory = 'coaching' | 'wifi';

export const CUSTOMER_SERVICE_CATEGORIES: CustomerServiceCategory[] = ['coaching', 'wifi'];

export type CoachingCategory = 'class_1_8' | 'ssc' | 'hsc' | 'bba' | 'admission';

/**
 * Moderation state of an owner-submitted listing.
 *
 * Admin-curated rows default to `approved`; a customer row starts `draft` or
 * `pending` and only becomes public once an admin approves it. An owner edit
 * sends an approved row back to `pending`.
 */
export type ServiceListingStatus = 'draft' | 'pending' | 'approved' | 'rejected';

export const SERVICE_LISTING_STATUS_META: Record<
  ServiceListingStatus,
  { labelBn: string; className: string; descriptionBn: string }
> = {
  draft: {
    labelBn: 'জমা দেওয়া হয়নি',
    className: 'bg-slate-100 text-slate-700',
    descriptionBn: 'এখনো জমা দেওয়া হয়নি। শুধু আপনি দেখতে পাচ্ছেন।',
  },
  pending: {
    labelBn: 'পর্যালোচনাধীন',
    className: 'bg-amber-100 text-amber-800',
    descriptionBn: 'অনুমোদনের জন্য অপেক্ষমাণ। অনুমোদনের পর সবার জন্য দেখা যাবে।',
  },
  approved: {
    labelBn: 'প্রকাশিত',
    className: 'bg-emerald-100 text-emerald-800',
    descriptionBn: 'অনুমোদিত ও সবার জন্য দৃশ্যমান।',
  },
  rejected: {
    labelBn: 'অনুমোদিত হয়নি',
    className: 'bg-rose-100 text-rose-800',
    descriptionBn: 'কারণ দেখে তথ্য সংশোধন করে আবার জমা দিন।',
  },
};

export interface ServiceListing {
  id: string;
  publicId?: string;
  publicCode?: string;
  category: ServiceCategory;
  slug: string;
  titleBn: string;
  subtitleBn?: string;
  summaryBn?: string;
  descriptionBn?: string;
  imageUrl?: string;
  logoUrl?: string;
  /** Gallery images; customer coaching profiles are limited to four. */
  photos?: string[];
  coachingCategory?: CoachingCategory;
  /** Active batch years, populated only for coaching directory filtering. */
  coachingBatchYears?: number[];
  areaIds: string[];
  tags: string[];
  monthlyFeeMin?: number;
  monthlyFeeMax?: number;
  priceMin?: number;
  priceMax?: number;
  speedMbps?: number;
  fareMin?: number;
  fareMax?: number;
  originBn?: string;
  destinationBn?: string;
  seatCount?: number;
  travelDays?: string[];
  stops?: string[];
  journeyDurationBn?: string;
  contactPhonePrivate?: string;
  isActive: boolean;
  isFeatured: boolean;
  createdAt: string;
  updatedAt: string;
  // --- vehicle / bus directory fields -----------------------------------
  /** "Toyota Axio", "Honda Grace", "Bajaj RE" — distinct from the listing title. */
  modelNameBn?: string;
  modelYear?: number;
  /** null = unknown, which is different from false ("definitely not air-con"). */
  hasAc?: boolean;
  driverIncluded?: boolean;
  driverNameBn?: string;
  /** "সকাল ৭টা – বিকাল ৬টা", "শুধু রাত্রি". */
  availableTimeBn?: string;
  /** Explicit rate used only for an estimated vehicle booking fare. */
  ratePerKm?: number;
  minimumFare?: number;
  additionalFee?: number;
  additionalFeeNoteBn?: string;
  availableFacilities?: string[];
  unavailableFacilities?: string[];
  /**
   * How the numbers above should be read: "প্রতি কিলোমিটার", "প্রতি দিন",
   * "পুরো ভাড়া (ভাড়াও চালক)". Free text because the unit is a local
   * convention, not an enum anyone can enumerate correctly.
   */
  priceNoteBn?: string;
  // --- coaching / wifi / bus extensions -----------------------------------
  /**
   * The bus operating company ("শ্যামলী", "এনা"), kept separate from the title
   * so a search by operator name and a search by service name both work.
   */
  operatorBn?: string;
  /** A centre's or provider's street address. */
  addressBn?: string;
  /**
   * Published review aggregate. Read-only for every client — the database
   * recomputes both from published reviews whenever one is written, so a score
   * is never client-computed and never drifts from its reviews.
   */
  ratingAvg?: number;
  ratingCount?: number;
  // --- customer ownership + moderation ------------------------------------
  /**
   * The member who created the row, or undefined for an admin-curated one.
   * Presence is how the detail page tells a member submission apart from an
   * admin listing (and shows the right trust chip).
   */
  ownerId?: string;
  /** Only populated on the owner / admin read paths, never on the public list. */
  status?: ServiceListingStatus;
  rejectionReason?: string;
  publishedAt?: string;
  /**
   * The number the owner publishes for the public "কল করুন" button. Distinct
   * from `contactPhonePrivate`, which stays admin-only.
   */
  contactPhonePublic?: string;
  /** কোচিং: ভর্তি ও ফি সংক্রান্ত তথ্য. WiFi: —. */
  admissionInfoBn?: string;
  /** কোচিং: এককালীন ভর্তি ফি. */
  admissionFee?: number;
  /** WiFi: এককালীন সংযোগ/ইনস্টলেশন ফি. Coaching: —. */
  connectionFee?: number;
  /** WiFi: সংযোগের শর্ত / শর্তাবলি. Coaching: —. */
  termsBn?: string;
  /**
   * Only set on `lib/vehicle-demo-data.ts` rows. The directory's "showing demo
   * data" state is per-category, so this has to ride on the row: one demo
   * listing in a category of real ones is still a demo listing.
   */
  isDemo?: boolean;
}

/** The write-side shape an admin form produces. */
export type ServiceListingInput = Omit<
  ServiceListing,
  'id' | 'createdAt' | 'updatedAt'
>;

export type VehicleKind = 'গাড়ি' | 'অটো' | 'CNG';

export const VEHICLE_KINDS: VehicleKind[] = ['গাড়ি', 'অটো', 'CNG'];

// ---------------------------------------------------------------------------
// Directory sub-entities (teachers, batches, packages) + reviews
// ---------------------------------------------------------------------------

/**
 * A teacher attached to a coaching centre.
 *
 * `subjects` stores the COACHING_SUBJECTS slugs an admin ticked, plus any free
 * text; the UI resolves the slugs through `tagLabel` so a raw slug is never
 * printed at a reader.
 */
export interface CoachingTeacher {
  id: string;
  listingId: string;
  nameBn: string;
  subjects: string[];
  qualificationBn?: string;
  experienceBn?: string;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type CoachingTeacherInput = Omit<CoachingTeacher, 'id' | 'createdAt' | 'updatedAt'>;

/**
 * A batch announcement for a coaching centre.
 *
 * There is deliberately no `expires_at` and no automatic removal: an admin
 * announcement stays visible and editable until an admin edits or deactivates
 * it, including after two days. See `is_active`.
 */
export interface CoachingBatch {
  id: string;
  listingId: string;
  titleBn: string;
  batchYear?: number;
  batchStatus?: 'new' | 'old';
  startDate?: string;
  weekdayIds: CoachingWeekday[];
  startTimeLocal?: string;
  endTimeLocal?: string;
  /** Legacy free-text value retained for batches created before schedule fields. */
  startTime?: string;
  noteBn?: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type CoachingBatchInput = Omit<
  CoachingBatch,
  'id' | 'createdAt' | 'updatedAt' | 'weekdayIds' | 'startTimeLocal' | 'endTimeLocal'
> & {
  weekdayIds?: CoachingWeekday[];
  startTimeLocal?: string;
  endTimeLocal?: string;
};

export const COACHING_WEEKDAYS = [
  { id: 'saturday', labelBn: 'শনিবার' },
  { id: 'sunday', labelBn: 'রবিবার' },
  { id: 'monday', labelBn: 'সোমবার' },
  { id: 'tuesday', labelBn: 'মঙ্গলবার' },
  { id: 'wednesday', labelBn: 'বুধবার' },
  { id: 'thursday', labelBn: 'বৃহস্পতিবার' },
  { id: 'friday', labelBn: 'শুক্রবার' },
] as const;

export type CoachingWeekday = (typeof COACHING_WEEKDAYS)[number]['id'];

export const COACHING_WEEKDAY_GROUPS: {
  id: string;
  labelBn: string;
  weekdayIds: CoachingWeekday[];
}[] = [
  {
    id: 'sat-mon-thu',
    labelBn: 'শনি-সোম-বৃহস্পতি',
    weekdayIds: ['saturday', 'monday', 'thursday'],
  },
  {
    id: 'sun-tue-wed',
    labelBn: 'রবি-মঙ্গল-বুধ',
    weekdayIds: ['sunday', 'tuesday', 'wednesday'],
  },
];

export function coachingWeekdayLabel(weekdayIds: CoachingWeekday[]): string {
  const selected = new Set(weekdayIds);
  const group = COACHING_WEEKDAY_GROUPS.find(
    (candidate) =>
      candidate.weekdayIds.length === selected.size &&
      candidate.weekdayIds.every((weekday) => selected.has(weekday))
  );
  return group?.labelBn ??
    COACHING_WEEKDAYS.filter((day) => selected.has(day.id)).map((day) => day.labelBn).join(', ');
}

function formatCoachingClock(value: string): string {
  const match = /^([01]\d|2[0-3]):[0-5]\d$/.exec(value);
  if (!match) return value;
  const hour = Number(match[1]) % 12 || 12;
  return `${toBn(hour)}টা`;
}

export function coachingTimeRange(start?: string, end?: string): string | undefined {
  if (!start || !end) return undefined;
  return `${formatCoachingClock(start)} থেকে ${formatCoachingClock(end)}`;
}

/** One purchasable internet package under a WiFi provider. */
export interface WifiPackage {
  id: string;
  listingId: string;
  nameBn: string;
  speedMbps?: number;
  price?: number;
  offerLabelBn?: string;
  offerConditionsBn?: string;
  /** One-time connection/installation fee for this specific package. */
  connectionFee?: number;
  /** ISO date the offer runs out; printed as "অফার শেষ: …". */
  offerExpiresOn?: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type WifiPackageInput = Omit<WifiPackage, 'id' | 'createdAt' | 'updatedAt'>;

/**
 * The write-side shape the customer create/edit form produces.
 *
 * Narrower than `ServiceListingInput` on purpose: an owner never chooses slug,
 * status, featured/published state, the admin-only private contact, or the
 * review aggregate. Slug is generated server-side; moderation state is forced
 * by the database guard trigger.
 */
export interface CustomerServiceListingInput {
  category: CustomerServiceCategory;
  coachingCategory?: CoachingCategory;
  titleBn: string;
  subtitleBn?: string;
  summaryBn?: string;
  descriptionBn?: string;
  imageUrl?: string;
  logoUrl?: string;
  photos?: string[];
  areaIds: string[];
  /** Free-form highlight chips (coaching: classes/subjects/সুবিধা). */
  tags: string[];
  addressBn?: string;
  contactPhonePublic: string;
  // coaching
  monthlyFeeMin?: number;
  monthlyFeeMax?: number;
  admissionInfoBn?: string;
  admissionFee?: number;
  // wifi
  priceMin?: number;
  priceMax?: number;
  speedMbps?: number;
  connectionFee?: number;
  termsBn?: string;
}

/** Reviews only ever attach to these two curated categories. */
export type DirectoryReviewCategory = 'coaching' | 'wifi';

export interface DirectoryReview {
  id: string;
  category: DirectoryReviewCategory;
  listingId: string;
  authorId: string;
  /** Shown on the review card; falls back to "সদস্য" when the profile has none. */
  authorName?: string;
  rating: number;
  commentBn?: string;
  isPublished: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DirectoryReviewInput {
  category: DirectoryReviewCategory;
  listingId: string;
  rating: number;
  commentBn?: string;
}


// ---------------------------------------------------------------------------
// User-authored posts
// ---------------------------------------------------------------------------

export type PostKind = 'news' | 'job' | 'buy_sell';
export type PostStatus = 'pending' | 'approved' | 'rejected';
export type MarketplaceStatus = 'available' | 'sold' | 'closed';

export interface CommunityPost {
  id: string;
  kind: PostKind;
  slug: string;
  authorId: string;
  authorName?: string;
  /**
   * The author's contact number.
   *
   * Not a free-for-all: it is populated from the signed-in user's profile, or
   * typed by a guest at post time, and it is only ever READ BACK on a
   * marketplace item — a news article or a job ad never exposes it. See
   * `fetchMarketContact` in the service layer for the server-side gate.
   */
  authorPhone?: string;
  /** Separate WhatsApp number when it differs from the call number. */
  whatsappNumber?: string;
  titleBn: string;
  summaryBn?: string;
  bodyBn?: string;
  coverImageUrl?: string;
  /**
   * Extra product photos beyond the cover. A marketplace item with one photo
   * reads as a scam, so the detail page shows a gallery when this is present
   * and falls back to the cover alone when it is not.
   */
  gallery?: string[];
  category?: string;
  areaId?: string;
  tags: string[];
  salaryMin?: number;
  salaryMax?: number;
  price?: number;
  jobType?: string;
  deadline?: string;
  conditionLabel?: string;
  status: PostStatus;
  marketplaceStatus?: MarketplaceStatus;
  /**
   * Why a moderator rejected this post. Set only by an admin (the service
   * layer strips it from every author write and a DB trigger refuses to let
   * a non-admin touch it); readable by the author through their own row so
   * the dashboard can say *what* to fix instead of just "not approved".
   */
  rejectionReason?: string;
  /**
   * Hiring organisation for `kind === 'job'` — the company name the reader
   * sees on the ad. NULL for every other kind.
   */
  organizationBn?: string;
  isFeatured: boolean;
  publishedAt?: string;
  createdAt: string;
  updatedAt: string;
  /** Only set on `lib/market-demo-data.ts` rows. See `ServiceListing.isDemo`. */
  isDemo?: boolean;
}

/**
 * What an author may write.
 *
 * `authorPhone` and `whatsappNumber` are re-declared as nullable because a
 * seller has to be able to *withdraw* a number, not only set one: sending
 * `undefined` would skip the column and leave the old number stored on a post
 * the seller believes they have cleaned up. `null` writes SQL NULL; `undefined`
 * leaves the column alone.
 */
export type CommunityPostInput = Omit<
  CommunityPost,
  'id' | 'createdAt' | 'updatedAt' | 'authorPhone' | 'whatsappNumber'
> & {
  authorPhone?: string | null;
  whatsappNumber?: string | null;
  rejectionReason?: string | null;
};

// ---------------------------------------------------------------------------
// Emergency directory
// ---------------------------------------------------------------------------

export type EmergencyService = 'doctor' | 'police' | 'ambulance' | 'fire_service';

export interface EmergencyContact {
  id: string;
  service: EmergencyService;
  nameBn: string;
  organizationBn?: string;
  areaId?: string;
  addressBn?: string;
  phone: string;
  sourceNote?: string;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type EmergencyContactInput = Omit<EmergencyContact, 'id' | 'createdAt' | 'updatedAt'>;

// ---------------------------------------------------------------------------
// Vehicle rental requests
// ---------------------------------------------------------------------------

export type VehicleRequestStatus = 'new' | 'reviewing' | 'contacted' | 'approved' | 'rejected' | 'closed';

export interface VehicleRequest {
  id: string;
  referenceCode?: string;
  vehicleListingId?: string;
  vehicleKind: VehicleKind;
  vehicleName?: string;
  customerId?: string;
  contactName: string;
  contactPhone: string;
  pickupAreaId?: string;
  destinationAreaId?: string;
  travelDate?: string;
  travelTime?: string;
  /** যাত্রী সংখ্যা — decides which vehicle is right, so it is asked up front. */
  passengerCount?: number;
  /** "এক ঘণ্টা", "সারাদিন", "দুই দিন" — the hire term, not a timestamp. */
  tripDuration?: string;
  /** Optional ceiling the rider has in mind, in taka. */
  budget?: number;
  notes?: string;
  estimatedDistanceKm?: number;
  distanceSource?: 'road_route' | 'manual_estimate';
  status: VehicleRequestStatus;
  assignedVehicleListingId?: string;
  assignedDriverName?: string;
  assignedDriverPhone?: string;
  adminNotes?: string;
  ratePerKm?: number;
  minimumFare?: number;
  estimatedFare?: number;
  additionalFee?: number;
  additionalFeeNoteBn?: string;
  createdAt: string;
  updatedAt: string;
}

export interface VehicleRequestInput {
  vehicleListingId?: string;
  vehicleKind: VehicleKind;
  vehicleName?: string;
  contactName: string;
  contactPhone: string;
  pickupAreaId?: string;
  destinationAreaId?: string;
  travelDate?: string;
  travelTime?: string;
  passengerCount?: number;
  tripDuration?: string;
  budget?: number;
  notes?: string;
  estimatedDistanceKm: number;
  distanceSource: 'road_route' | 'manual_estimate';
}

// ---------------------------------------------------------------------------
// Taxonomy — vocabulary only, never content
// ---------------------------------------------------------------------------

/** Classes a coaching centre can teach. */
export const COACHING_CLASSES: { id: string; labelBn: string }[] = [
  { id: 'primary', labelBn: 'প্রাথমিক' },
  { id: 'secondary', labelBn: 'মাধ্যমিক' },
  { id: 'higher-secondary', labelBn: 'উচ্চ মাধ্যমিক' },
  { id: 'hsc', labelBn: 'এইচএসসি' },
  { id: 'alim', labelBn: 'আলিম' },
  { id: 'university-admission', labelBn: 'বিশ্ববিদ্যালয় ভর্তি' },
  { id: 'competitive', labelBn: 'প্রতিযোগিতা' },
];

/** Subjects a coaching centre can offer. */
export const COACHING_SUBJECTS: { id: string; labelBn: string }[] = [
  { id: 'math', labelBn: 'গণিত' },
  { id: 'higher_math', labelBn: 'উচ্চতর গণিত' },
  { id: 'physics', labelBn: 'পদার্থবিজ্ঞান' },
  { id: 'chemistry', labelBn: 'রসায়ন' },
  { id: 'biology', labelBn: 'জীববিজ্ঞান' },
  { id: 'english', labelBn: 'ইংরেজি' },
  { id: 'bangla', labelBn: 'বাংলা' },
  { id: 'ict', labelBn: 'আইসিটি' },
  { id: 'science', labelBn: 'সাধারণ বিজ্ঞান' },
  { id: 'social_studies', labelBn: 'বাংলাদেশ ও বিশ্বপরিচয়' },
  { id: 'religion', labelBn: 'ধর্ম ও নৈতিক শিক্ষা' },
  { id: 'accounting', labelBn: 'হিসাববিজ্ঞান' },
  { id: 'business_studies', labelBn: 'ব্যবসায় উদ্যোগ' },
  { id: 'finance', labelBn: 'ফিন্যান্স ও ব্যাংকিং' },
  { id: 'economics', labelBn: 'অর্থনীতি' },
  { id: 'civics', labelBn: 'পৌরনীতি ও সুশাসন' },
  { id: 'sociology', labelBn: 'সমাজবিজ্ঞান' },
  { id: 'logic', labelBn: 'যুক্তিবিদ্যা' },
  { id: 'history', labelBn: 'ইতিহাস' },
  { id: 'general_knowledge', labelBn: 'সাধারণ জ্ঞান' },
  { id: 'analytical_ability', labelBn: 'বিশ্লেষণী দক্ষতা' },
  { id: 'medical_admission', labelBn: 'মেডিকেল ভর্তি প্রস্তুতি' },
  { id: 'engineering_admission', labelBn: 'প্রকৌশল ভর্তি প্রস্তুতি' },
  { id: 'university_admission', labelBn: 'বিশ্ববিদ্যালয় ভর্তি প্রস্তুতি' },
];

export const COACHING_SUBJECTS_BY_CATEGORY: Record<
  CoachingCategory,
  { id: string; labelBn: string }[]
> = {
  class_1_8: COACHING_SUBJECTS.filter((subject) =>
    ['bangla', 'english', 'math', 'science', 'social_studies', 'ict', 'religion'].includes(subject.id)
  ),
  ssc: COACHING_SUBJECTS.filter((subject) =>
    [
      'bangla', 'english', 'math', 'higher_math', 'physics', 'chemistry', 'biology',
      'ict', 'social_studies', 'religion', 'accounting', 'business_studies',
      'finance', 'economics',
    ].includes(subject.id)
  ),
  hsc: COACHING_SUBJECTS.filter((subject) =>
    [
      'bangla', 'english', 'ict', 'physics', 'chemistry', 'biology', 'higher_math',
      'accounting', 'business_studies', 'finance', 'economics', 'civics',
      'sociology', 'logic', 'history',
    ].includes(subject.id)
  ),
  bba: COACHING_SUBJECTS.filter((subject) =>
    ['accounting', 'business_studies', 'finance', 'economics', 'english', 'analytical_ability'].includes(subject.id)
  ),
  admission: COACHING_SUBJECTS.filter((subject) =>
    [
      'bangla', 'english', 'math', 'higher_math', 'physics', 'chemistry', 'biology',
      'general_knowledge', 'analytical_ability', 'medical_admission',
      'engineering_admission', 'university_admission',
    ].includes(subject.id)
  ),
};

/** Directory categories used to classify coaching centres. */
export const COACHING_CATEGORIES: { id: CoachingCategory; labelBn: string }[] = [
  { id: 'class_1_8', labelBn: 'ক্লাস ১–৮' },
  { id: 'ssc', labelBn: 'এসএসসি (ক্লাস ৯–১০)' },
  { id: 'hsc', labelBn: 'এইচএসসি' },
  { id: 'bba', labelBn: 'বিবিএ' },
  { id: 'admission', labelBn: 'ভর্তি' },
];

export function isCoachingCategory(value: unknown): value is CoachingCategory {
  return COACHING_CATEGORIES.some((category) => category.id === value);
}

/** Bus body/category types. */
export const BUS_TYPES: { id: string; labelBn: string }[] = [
  { id: 'ac', labelBn: 'এসি' },
  { id: 'non-ac', labelBn: 'নন-এসি' },
  { id: 'luxury', labelBn: 'লাক্সারি' },
  { id: 'double-decker', labelBn: 'ডাবল ডেকার' },
];

/** News desk categories. */
export const NEWS_CATEGORIES: { id: string; labelBn: string }[] = [
  { id: 'mymensingh', labelBn: 'ময়মনসিংহ' },
  { id: 'national', labelBn: 'জাতীয়' },
  { id: 'politics', labelBn: 'রাজনীতি' },
  { id: 'education', labelBn: 'শিক্ষা' },
  { id: 'jobs', labelBn: 'চাকরি' },
  { id: 'economy', labelBn: 'অর্থনীতি' },
  { id: 'sports', labelBn: 'খেলাধুলা' },
  { id: 'entertainment', labelBn: 'বিনোদন' },
  { id: 'technology', labelBn: 'প্রযুক্তি' },
  { id: 'others', labelBn: 'অন্যান্য' },
];

/** Job portal types. */
export const JOB_TYPES: { id: string; labelBn: string }[] = [
  { id: 'full-time', labelBn: 'ফুল টাইম' },
  { id: 'part-time', labelBn: 'পার্ট টাইম' },
  { id: 'contract', labelBn: 'কন্ট্রাক্ট' },
  { id: 'internship', labelBn: 'ইন্টার্নশিপ' },
  { id: 'govt', labelBn: 'সরকারি চাকরি' },
];

/** Job experience bands. */
export const JOB_EXPERIENCE: { id: string; labelBn: string }[] = [
  { id: 'fresher', labelBn: 'ফ্রেশার' },
  { id: '1-2', labelBn: '১–২ বছর' },
  { id: '3-5', labelBn: '৩–৫ বছর' },
  { id: '5+', labelBn: '৫+ বছর' },
];

/** Job education bands. */
export const JOB_EDUCATION: { id: string; labelBn: string }[] = [
  { id: 'ssc', labelBn: 'এসএসসি' },
  { id: 'hsc', labelBn: 'এইচএসসি' },
  { id: 'graduation', labelBn: 'স্নাতক' },
  { id: 'post-graduation', labelBn: 'স্নাতকোত্তর' },
  { id: 'any', labelBn: 'যেকোনো' },
];

/**
 * Buy-sell item categories.
 *
 * `vehicle` is a legacy id kept for rows written before বাইক and গাড়ি were split
 * apart. It is deliberately absent from this list, so it never appears as a
 * filter chip, but `tagLabel` still resolves it — a post filed under the old id
 * keeps rendering its own category instead of silently losing it.
 */
export const MARKET_CATEGORIES: { id: string; labelBn: string }[] = [
  { id: 'mobile', labelBn: 'মোবাইল' },
  { id: 'laptop', labelBn: 'ল্যাপটপ / কম্পিউটার' },
  { id: 'electronics', labelBn: 'ইলেকট্রনিক্স' },
  { id: 'furniture', labelBn: 'আসবাবপত্র' },
  { id: 'bike', labelBn: 'বাইক' },
  { id: 'car', labelBn: 'গাড়ি' },
  { id: 'books', labelBn: 'বই' },
  { id: 'clothing', labelBn: 'পোশাক' },
  { id: 'household', labelBn: 'বাসার জিনিসপত্র' },
  { id: 'other', labelBn: 'অন্যান্য' },
];

/** Buy-sell condition bands. */
export const MARKET_CONDITIONS: { id: string; labelBn: string }[] = [
  { id: 'new', labelBn: 'নতুন' },
  { id: 'like-new', labelBn: 'নতুনের মতো' },
  { id: 'good', labelBn: 'ভালো' },
  { id: 'used', labelBn: 'ব্যবহৃত' },
];

/**
 * Lucide icon name per marketplace category, for the category rail.
 *
 * A string rather than a component so this module stays free of JSX and the
 * component that owns the rail is the one that decides how to draw it. Every
 * value is a real lucide export, so the rail can index the icon set directly.
 */
export const MARKET_CATEGORY_ICONS: Record<string, string> = {
  mobile: 'Smartphone',
  laptop: 'Laptop',
  electronics: 'Plug',
  furniture: 'Armchair',
  bike: 'Bike',
  car: 'Car',
  books: 'BookOpen',
  clothing: 'Shirt',
  household: 'BedDouble',
  vehicle: 'Car',
  other: 'Package',
};

// ---------------------------------------------------------------------------
// Fee / price bands used by the "range" filters
// ---------------------------------------------------------------------------

/**
 * A numeric band for the shared "range" filter group.
 *
 * `min` is optional because the open-ended ends are the common case: a reader
 * choosing "৫০০ টাকার কম" wants a ceiling and a reader choosing "৩০০০ টাকার বেশি"
 * wants a floor. Omitting the missing bound is what expresses that, and it
 * keeps the single shape usable for the matcher, which defaults a missing `min`
 * to 0.
 */
export type PriceBand = { id: string; labelBn: string; min?: number; max?: number };

/** Monthly coaching fee, in taka. */
export const COACHING_FEE_BANDS: PriceBand[] = [
  { id: 'f0', labelBn: '৫০০ টাকার কম', max: 500 },
  { id: 'f1', labelBn: '৫০০ – ১০০০', min: 500, max: 1000 },
  { id: 'f2', labelBn: '১০০০ – ২০০০', min: 1000, max: 2000 },
  { id: 'f3', labelBn: '২০০০ – ৩০০০', min: 2000, max: 3000 },
  { id: 'f4', labelBn: '৩০০০ টাকার বেশি', min: 3000 },
];

/** Monthly WiFi price, in taka. */
export const WIFI_PRICE_BANDS: PriceBand[] = [
  { id: 'p0', labelBn: '৫০০ টাকার কম', max: 500 },
  { id: 'p1', labelBn: '৫০০ – ১০০০', min: 500, max: 1000 },
  { id: 'p2', labelBn: '১০০০ – ১৫০০', min: 1000, max: 1500 },
  { id: 'p3', labelBn: '১৫০০ – ২০০০', min: 1500, max: 2000 },
  { id: 'p4', labelBn: '২০০০ টাকার বেশি', min: 2000 },
];

/** WiFi speed bands, in Mbps. */
export const WIFI_SPEED_BANDS: PriceBand[] = [
  { id: 's0', labelBn: '১০ Mbps পর্যন্ত', max: 10 },
  { id: 's1', labelBn: '১১ – ২০ Mbps', min: 11, max: 20 },
  { id: 's2', labelBn: '২১ – ৫০ Mbps', min: 21, max: 50 },
  { id: 's3', labelBn: '৫০ Mbps-এর বেশি', min: 51 },
];

/** Bus fare bands, one way, in taka. */
export const BUS_FARE_BANDS: PriceBand[] = [
  { id: 't0', labelBn: '২০০ টাকার কম', max: 200 },
  { id: 't1', labelBn: '২০০ – ৩০০', min: 200, max: 300 },
  { id: 't2', labelBn: '৩০০ – ৪০০', min: 300, max: 400 },
  { id: 't3', labelBn: '৪০০ – ৫০০', min: 400, max: 500 },
  { id: 't4', labelBn: '৫০০ টাকার বেশি', min: 500 },
];

/** Buy-sell price bands, in taka. */
export const MARKET_PRICE_BANDS: PriceBand[] = [
  { id: 'm0', labelBn: '১০০০ টাকার কম', max: 1000 },
  { id: 'm1', labelBn: '১০০০ – ৫০০০', min: 1000, max: 5000 },
  { id: 'm2', labelBn: '৫০০০ – ১৫০০০', min: 5000, max: 15000 },
  { id: 'm3', labelBn: '১৫০০০ – ৫০০০০', min: 15000, max: 50000 },
  { id: 'm4', labelBn: '৫০০০০ টাকার বেশি', min: 50000 },
];

// ---------------------------------------------------------------------------
// Page configuration
// ---------------------------------------------------------------------------

/**
 * Card layout per category. This is the one place that encodes the
 * "how many cards per row" rule so a page cannot get it wrong.
 */
export type GridColumns = 1 | 2 | 3 | 4 | 5;

export interface CategoryUiConfig {
  category: ServiceCategory;
  route: string;
  title: string;
  subtitle: string;
  /** Meta description for the page's `metadata` export. */
  seoDescription: string;
  placeholder: string;
  /** Noun used in the result count and the empty state. */
  noun: string;
  searchNoun: string;
  /** Trust chips under the title. */
  highlights: string[];
  /** Mobile / desktop cards per row. */
  mobileCols: GridColumns;
  desktopCols: GridColumns;
  /** Whether the empty state should invite an admin to add the first row. */
  adminOwned: boolean;
  /**
   * Whether a signed-in provider can add and manage their own listing here.
   * Drives the "আপনার প্রতিষ্ঠান যোগ করুন" call-to-action on the directory.
   */
  customerOwned: boolean;
}

export const CATEGORY_UI: Record<ServiceCategory, CategoryUiConfig> = {
  coaching: {
    category: 'coaching',
    route: '/coaching',
    title: 'কোচিং সেন্টার',
    subtitle: '',
    placeholder: 'কোচিং সেন্টার, এলাকা বা বিষয় লিখে খুঁজুন...',
    seoDescription:
      'ময়মনসিংহের কোচিং সেন্টার তালিকা। ক্লাস, বিষয়, এলাকা ও মাসিক ফি অনুযায়ী খুঁজে সরাসরি যোগাযোগ করুন।',
    noun: 'কোচিং',
    searchNoun: 'কোচিং সেন্টার',
    highlights: [],
    mobileCols: 1,
    desktopCols: 2,
    adminOwned: true,
    customerOwned: true,
  },
  wifi: {
    category: 'wifi',
    route: '/wifi',
    title: 'ওয়াইফাই ও ইন্টারনেট',
    subtitle: '',
    placeholder: 'প্রোভাইডার, প্যাকেজ বা এলাকা লিখে খুঁজুন...',
    seoDescription:
      'ময়মনসিংহের লোকাল ওয়াইফাই ও ইন্টারনেট প্রদানকারীদের স্পিড, মাসিক দাম ও সার্ভিস এলাকা দেখুন, তারপর সঠিক প্যাকেজ বেছে নিন।',
    noun: 'প্রোভাইডার',
    searchNoun: 'ইন্টারনেট প্রদানকারী',
    highlights: ['স্পিড ও দাম স্পষ্ট', 'সার্ভিস এলাকা', 'সরাসরি কল করুন'],
    mobileCols: 1,
    desktopCols: 2,
    adminOwned: true,
    customerOwned: true,
  },
  bus: {
    category: 'bus',
    route: '/bus-ticket',
    title: 'বাস টিকিট',
    subtitle:
      'ময়মনসিংহ থেকে বাইরে যাওয়ার বাসের তালিকা — গন্তব্য, ধরন ও ভাড়া অনুযায়ী খুঁজুন।',
    placeholder: 'গন্তব্য বা বাসের নাম লিখে খুঁজুন...',
    seoDescription:
      'ময়মনসিংহ থেকে বাইরে যাওয়ার বাসের তালিকা। গন্তব্য, বাসের ধরন ও এক-ওয়ে ভাড়া অনুযায়ী খুঁজুন।',
    noun: 'বাস',
    searchNoun: 'বাস',
    highlights: ['অ্যাডমিন তালিকাভুক্ত', 'ভাড়া স্পষ্ট', 'গন্তব্য অনুযায়ী খোঁজা'],
    mobileCols: 2,
    desktopCols: 4,
    adminOwned: true,
    customerOwned: false,
  },
  vehicle: {
    category: 'vehicle',
    route: '/gari-auto-cng',
    title: 'গাড়ি ভাড়া',
    subtitle:
      'ময়মনসিংহে ভাড়ার গাড়ি খুঁজুন। অটো বা CNG ভাড়ার জন্য আলাদা বুকিং অনুরোধ পাঠান।',
    placeholder: 'গাড়ির মডেল বা এলাকা লিখে খুঁজুন...',
    seoDescription:
      'ময়মনসিংহে ভাড়ার গাড়ির ছবি, আসন ও ভাড়ার তথ্য দেখুন। অটো ও CNG-এর জন্য আলাদা বুকিং অনুরোধ পাঠান।',
    noun: 'গাড়ি',
    searchNoun: 'গাড়ি',
    highlights: ['গাড়ির ছবি ও তথ্য', 'ভাড়ার অনুরোধ পাঠান', 'ময়মনসিংহের এলাকা'],
    mobileCols: 2,
    desktopCols: 4,
    adminOwned: true,
    customerOwned: false,
  },
};

/** Tailwind grid class for a category's card layout. */
export function categoryGridClass(ui: CategoryUiConfig): string {
  const mobile: Record<GridColumns, string> = {
    1: 'grid-cols-1',
    2: 'grid-cols-2',
    3: 'grid-cols-2',
    4: 'grid-cols-2',
    5: 'grid-cols-2',
  };
  const desktop: Record<GridColumns, string> = {
    1: 'lg:grid-cols-1',
    2: 'lg:grid-cols-2',
    3: 'md:grid-cols-3',
    4: 'lg:grid-cols-4',
    5: 'lg:grid-cols-5',
  };
  return `grid gap-2.5 sm:gap-3 ${mobile[ui.mobileCols]} md:grid-cols-3 ${desktop[ui.desktopCols]}`;
}

/** Emergency page configuration. */
export interface EmergencyUiConfig {
  service: EmergencyService;
  route: string;
  title: string;
  subtitle: string;
  noun: string;
  placeholder: string;
  highlights: string[];
  /**
   * Shown under the list on every emergency page.
   *
   * The point is to stop a reader treating a curated directory as a guarantee:
   * a station's published line can be busy, and a real emergency may need the
   * national control room. This states that plainly instead of leaving the
   * reader to assume the first number they see is the only option.
   */
  disclaimer: string;
}

export const EMERGENCY_UI: Record<EmergencyService, EmergencyUiConfig> = {
  doctor: {
    service: 'doctor',
    route: '/doctors',
    title: 'ডাক্তার',
    subtitle:
      'ময়মনসিংহে চিকিৎসা সেবা দেওয়া প্রতিষ্ঠান ও চিকিৎসকদের তালিকা — যোগাযোগের তথ্য সরাসরি।',
    noun: 'চিকিৎসক',
    placeholder: 'ডাক্তার, প্রতিষ্ঠান বা এলাকা লিখে খুঁজুন...',
    highlights: ['অ্যাডমিন যাচাইকৃত তথ্য', 'সরাসরি যোগাযোগ', 'এলাকাভিত্তিক তালিকা'],
    disclaimer:
      'জরুরি অবস্থায় প্রথমে নিকটস্থ হাসপাতালের জরুরি বিভাগে যোগাযোগ করুন। এখানে কেবল অ্যাডমিন-যাচাইকৃত স্থানীয় যোগাযোগের তথ্য দেখানো হয়।',
  },
  police: {
    service: 'police',
    route: '/police',
    title: 'পুলিশ',
    subtitle: 'ময়মনসিংহের থানা ও নিরাপত্তা সেবার তালিকা — ঠিকানা ও ফোন নম্বর সহ।',
    noun: 'থানা',
    placeholder: 'থানা বা এলাকা লিখে খুঁজুন...',
    highlights: ['অ্যাডমিন যাচাইকৃত তথ্য', 'সরাসরি যোগাযোগ', 'এলাকাভিত্তিক তালিকা'],
    disclaimer:
      'জরুরি অবস্থায় প্রথমে নিকটস্থ থানায় যোগাযোগ করুন। প্রাণঘাতী বা বড় ঝুঁকির পরিস্থিতিতে জাতীয় নিয়ন্ত্রণ কক্ষে কল করুন।',
  },
  ambulance: {
    service: 'ambulance',
    route: '/ambulance',
    title: 'অ্যাম্বুলেন্স',
    subtitle: 'ময়মনসিংহে রোগী পরিবহন সেবা দেওয়া প্রতিষ্ঠানের তালিকা।',
    noun: 'অ্যাম্বুলেন্স সেবা',
    placeholder: 'সেবা, প্রতিষ্ঠান বা এলাকা লিখে খুঁজুন...',
    highlights: ['অ্যাডমিন যাচাইকৃত তথ্য', 'সরাসরি যোগাযোগ', 'এলাকাভিত্তিক তালিকা'],
    disclaimer:
      'রোগী পরিবহনের জন্য প্রথমে স্থানীয় সেবা প্রদানকারীকে কল করুন। সেবা না পেলে জাতীয় জরুরি সেবা নম্বরে কল করুন।',
  },
  fire_service: {
    service: 'fire_service',
    route: '/fireservice',
    title: 'ফায়ার সার্ভিস',
    subtitle: 'ময়মনসিংহে অগ্নিনির্বাপণ ও উদ্ধার সেবার তালিকা।',
    noun: 'ফায়ার ইউনিট',
    placeholder: 'ফায়ার ইউনিট বা এলাকা লিখে খুঁজুন...',
    highlights: ['অ্যাডমিন যাচাইকৃত তথ্য', 'সরাসরি যোগাযোগ', 'এলাকাভিত্তিক তালিকা'],
    disclaimer:
      'অগ্নিকাণ্ড বা উদ্ধারের প্রয়োজনে প্রথমে নিকটস্থ ফায়ার ইউনিটে কল করুন, সঙ্গে সঙ্গে নিকটস্থ থানায়ও জানান।',
  },
};

// ---------------------------------------------------------------------------
// Formatting helpers
// ---------------------------------------------------------------------------

const BN_DIGITS = '০১২৩৪৫৬৭৮৯';

/**
 * Bangla numerals.
 *
 * Deliberately hand-rolled instead of `toLocaleString('bn-BD')`: Node and the
 * browser ship different ICU data, so Intl output is a hydration mismatch.
 */
export function toBn(value: string | number): string {
  return String(value).replace(/\d/g, (d) => BN_DIGITS[Number(d)]);
}

/** `৳১,২০০` — thousands-separated Bangla taka. */
export function bnTaka(value?: number): string {
  if (value == null || Number.isNaN(value)) return '';
  const grouped = Math.round(value)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `৳${toBn(grouped)}`;
}

/** Currency formatter for per-kilometre rates and fare estimates with paisha. */
export function bnTakaDecimal(value?: number): string {
  if (value == null || !Number.isFinite(value)) return '';
  return `৳${value.toLocaleString('bn-BD', { maximumFractionDigits: 2 })}`;
}

/** A taka range, collapsed when both ends are equal. */
export function bnTakaRange(min?: number, max?: number): string | undefined {
  if (min == null && max == null) return undefined;
  if (min != null && max != null) {
    return min === max ? bnTaka(min) : `${bnTaka(min)} – ${bnTaka(max)}`;
  }
  if (min != null) return `${bnTaka(min)}+`;
  return `${bnTaka(max)}`;
}

/** Bangla month names, indexed 0-11. */
const BN_MONTHS = [
  'জানুয়ারি',
  'ফেব্রুয়ারি',
  'মার্চ',
  'এপ্রিল',
  'মে',
  'জুন',
  'জুলাই',
  'আগস্ট',
  'সেপ্টেম্বর',
  'অক্টোবর',
  'নভেম্বর',
  'ডিসেম্বর',
];

/**
 * `YYYY-MM-DD` → `১৫ জানুয়ারি ২০২৬`.
 *
 * The string is split by hand rather than run through `new Date(...)`: parsing a
 * bare date as UTC and formatting it in a local zone shifts the day backwards for
 * anyone west of Greenwich, and `Intl` output differs between Node and the
 * browser. Returns `undefined` for anything that is not a real calendar date, so
 * a bad stored value shows as a missing fact rather than a wrong one.
 */
export function bnDate(value?: string | null): string | undefined {
  if (!value) return undefined;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value.trim());
  if (!match) return undefined;
  const year = Number(match[1]);
  const month = Number(match[2]) - 1;
  const day = Number(match[3]);
  if (month < 0 || month > 11) return undefined;
  if (day < 1 || day > 31) return undefined;
  return `${toBn(day)} ${BN_MONTHS[month]} ${toBn(year)}`;
}

/**
 * "৩ ঘণ্টা আগে" — how long ago a timestamp was, in the unit a reader cares about.
 *
 * Deliberately relative and deliberately short. On a marketplace the only
 * question a posted date answers is "is this thing still available", and that is
 * a question about recency, not about a calendar. A listing from eleven months
 * ago needs no more explanation than "১১ মাস আগে"; a listing from this morning
 * should not read "১৫ অক্টোবর ২০২৬" the same way it would in a news archive.
 *
 * `now` is injectable so the caller can pin it. Anything that renders on both
 * the server and the client must pass the server's clock, or the two renders
 * will disagree about whether a post is one day or two days old.
 */
export function bnRelativeTime(value?: string | null, now: number = Date.now()): string | undefined {
  if (!value) return undefined;
  const then = new Date(value).getTime();
  if (Number.isNaN(then)) return undefined;

  const seconds = Math.floor((now - then) / 1000);
  if (seconds < 0) return 'এইমাত্র';
  if (seconds < 60) return 'এইমাত্র';

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${toBn(minutes)} মিনিট আগে`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${toBn(hours)} ঘণ্টা আগে`;

  const days = Math.floor(hours / 24);
  if (days === 1) return 'গতকাল';
  if (days < 30) return `${toBn(days)} দিন আগে`;

  const months = Math.floor(days / 30);
  if (months < 12) return `${toBn(months)} মাস আগে`;

  return `${toBn(Math.floor(days / 365))} বছর আগে`;
}

/** Human label for a set of area ids, e.g. "চরপাড়া, টাউন হল". */
export function areaNames(areaIds: string[]): string {
  if (!areaIds || areaIds.length === 0) return '';
  const byId = new Map(getAllMCCAreas().map((a) => [a.id, a.nameBn]));
  const names = uniqueAreaNames(areaIds
    .map((id) => byId.get(id) ?? getAreaById(id)?.nameBn ?? id.trim())
    .filter(Boolean));
  if (names.length === 0) return '';
  if (names.length <= 2) return names.join(', ');
  return `${names[0]}, ${names[1]} +${toBn(names.length - 2)}টি`;
}

/**
 * A minimal, readable, URL-safe slug from Bangla or English text.
 *
 * Bangla has no usable Latin transliteration here, so the Bangla characters are
 * dropped and the result may be empty. Callers must therefore guarantee a
 * unique suffix rather than trusting the title to produce a slug.
 */
export function slugify(input: string): string {
  return input
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 60);
}

/** Guarantees a non-empty, unique-enough slug even for all-Bangla titles. */
export function uniqueSlug(input: string, fallback: string): string {
  const base = slugify(input);
  const seed = base || slugify(fallback) || 'item';
  return `${seed}-${Math.random().toString(36).slice(2, 8)}`;
}

// ---------------------------------------------------------------------------
// Tag vocabulary resolution
// ---------------------------------------------------------------------------

/**
 * Every taxonomy id above, flattened into one lookup.
 *
 * `service_listings.tags` is a single `TEXT[]` shared by every curated
 * category, and the curated facets (a coaching centre's class and subject) have
 * to match against it. Storing the taxonomy *slug* in that array is what makes
 * those facets work; the Bangla label lives here so the UI never has to print
 * a raw slug at a reader.
 *
 * A slug can legitimately appear in more than one taxonomy (`hsc` is both a
 * class and a centre type). They agree on the label, and first-wins keeps the
 * map deterministic.
 */
const TAG_LABELS: Map<string, string> = (() => {
  const map = new Map<string, string>();
  const taxonomies: { id: string; labelBn: string }[][] = [
    COACHING_CLASSES,
    COACHING_SUBJECTS,
    COACHING_CATEGORIES,
    BUS_TYPES,
    JOB_TYPES,
    JOB_EXPERIENCE,
    JOB_EDUCATION,
    MARKET_CATEGORIES,
    MARKET_CONDITIONS,
  ];
  for (const taxonomy of taxonomies) {
    for (const entry of taxonomy) {
      if (!map.has(entry.id)) map.set(entry.id, entry.labelBn);
    }
  }
  return map;
})();

/**
 * Resolves a stored tag to something displayable and searchable.
 *
 * Unknown values pass through unchanged on purpose: admins may add a free-text
 * tag ("ঈদ ভাড়া", "ভরী ক্যাম্প"), and hiding or mangling that would be worse than
 * showing it verbatim.
 */
export function tagLabel(tag: string): string {
  return TAG_LABELS.get(tag) ?? tag;
}

/** A listing's tags, resolved for display and for the search index. */
export function tagLabels(tags?: string[] | null): string[] {
  return (tags ?? []).filter(Boolean).map(tagLabel);
}
